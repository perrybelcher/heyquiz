import { FormSchemaType, QuizSubmissionResult, QuestionGradingResult, OutcomeTier } from "./schema";

export function gradeQuizSubmission(
  form: FormSchemaType,
  answers: Record<string, any>
): QuizSubmissionResult {
  let totalPointsPossible = 0;
  let totalPointsEarned = 0;
  const grading: QuestionGradingResult[] = [];

  for (const q of form.questions) {
    if (
      q.type === "heading" ||
      q.type === "subheading" ||
      q.type === "banner" ||
      q.type === "divider" ||
      q.type === "image_display" ||
      q.type === "rich_text" ||
      q.type === "accordion" ||
      q.type === "hidden"
    ) {
      continue;
    }

    const maxPoints = q.points || 0;
    totalPointsPossible += maxPoints;

    const userAnswer = answers[q.id];
    let earnedPoints = 0;
    let isCorrect = false;
    let correctAnswer: any = null;

    if (
      q.type === "multiple_choice" ||
      q.type === "picture_choice" ||
      q.type === "dropdown" ||
      q.type === "segmented" ||
      q.type === "like_dislike"
    ) {
      const correctOption = q.options?.find((opt) => opt.isCorrect);
      correctAnswer = correctOption ? correctOption.label : null;
      const userSelectedOption = q.options?.find((opt) => opt.id === userAnswer);

      if (correctOption && userSelectedOption && correctOption.id === userSelectedOption.id) {
        isCorrect = true;
        earnedPoints = maxPoints;
      }
    } else if (q.type === "switch") {
      const correctOption = q.options?.find((opt) => opt.isCorrect);
      correctAnswer = correctOption ? correctOption.label : null;
      if (correctOption && userAnswer === correctOption.id) {
        isCorrect = true;
        earnedPoints = maxPoints;
      }
    } else if (
      q.type === "multiselect" ||
      q.type === "checkboxes" ||
      q.type === "image_multiselect" ||
      q.type === "choice_matrix" ||
      q.type === "matrix_multiselect"
    ) {
      const correctOptionIds = q.options?.filter((opt) => opt.isCorrect).map((opt) => opt.id) || [];
      const userSelectedIds = Array.isArray(userAnswer) ? userAnswer : [];
      correctAnswer = q.options
        ?.filter((opt) => opt.isCorrect)
        .map((opt) => opt.label)
        .join(", ");

      const allCorrectSelected =
        correctOptionIds.length > 0 &&
        correctOptionIds.every((id) => userSelectedIds.includes(id)) &&
        userSelectedIds.every((id) => correctOptionIds.includes(id));

      if (allCorrectSelected) {
        isCorrect = true;
        earnedPoints = maxPoints;
      } else if (correctOptionIds.length > 0 && userSelectedIds.length > 0) {
        const truePositives = userSelectedIds.filter((id) => correctOptionIds.includes(id)).length;
        const falsePositives = userSelectedIds.filter((id) => !correctOptionIds.includes(id)).length;
        const netScore = Math.max(0, (truePositives - falsePositives) / correctOptionIds.length);
        earnedPoints = Math.round(netScore * maxPoints);
        isCorrect = earnedPoints === maxPoints;
      }
    } else if (q.type === "short_answer" || q.type === "email" || q.type === "number" || q.type === "phone") {
      correctAnswer = q.correctAnswerText || "";
      if (
        correctAnswer &&
        typeof userAnswer === "string" &&
        userAnswer.trim().toLowerCase() === correctAnswer.trim().toLowerCase()
      ) {
        isCorrect = true;
        earnedPoints = maxPoints;
      }
    } else {
      // Rating, opinion_scale, slider, nps, paragraph, date, file_upload
      if (userAnswer !== undefined && userAnswer !== null && userAnswer !== "") {
        earnedPoints = maxPoints;
        isCorrect = true;
      }
    }

    totalPointsEarned += earnedPoints;

    grading.push({
      questionId: q.id,
      questionTitle: q.title,
      type: q.type,
      maxPoints,
      earnedPoints,
      isCorrect,
      userAnswer: formatUserAnswerDisplay(q, userAnswer),
      correctAnswer: correctAnswer || "(Open-ended / Survey)",
      explanation: q.explanation || (q.options?.find((o) => o.id === userAnswer)?.explanation),
    });
  }

  const percentageScore =
    totalPointsPossible > 0
      ? Math.round((totalPointsEarned / totalPointsPossible) * 100)
      : 100;

  const passed = percentageScore >= (form.settings.passingScorePercentage ?? 70);

  // Match outcome tier
  let matchedTier: OutcomeTier | undefined = undefined;
  if (form.outcomeTiers && form.outcomeTiers.length > 0) {
    matchedTier = form.outcomeTiers.find(
      (tier) =>
        percentageScore >= tier.minScorePercent &&
        percentageScore <= tier.maxScorePercent
    );
    if (!matchedTier) {
      matchedTier = form.outcomeTiers[form.outcomeTiers.length - 1];
    }
  }

  return {
    formId: form.id,
    totalQuestions: form.questions.filter(
      (q) =>
        q.type !== "heading" &&
        q.type !== "subheading" &&
        q.type !== "banner" &&
        q.type !== "divider" &&
        q.type !== "image_display" &&
        q.type !== "rich_text" &&
        q.type !== "accordion" &&
        q.type !== "hidden"
    ).length,
    totalPointsPossible,
    totalPointsEarned,
    percentageScore,
    passed,
    matchedTier,
    grading,
    submittedAt: new Date().toISOString(),
  };
}

function formatUserAnswerDisplay(q: any, val: any): string {
  if (val === undefined || val === null || val === "") return "(No answer)";
  if (
    q.type === "multiple_choice" ||
    q.type === "dropdown" ||
    q.type === "switch" ||
    q.type === "picture_choice" ||
    q.type === "segmented" ||
    q.type === "like_dislike"
  ) {
    const opt = q.options?.find((o: any) => o.id === val);
    return opt ? opt.label : String(val);
  }
  if ((q.type === "multiselect" || q.type === "checkboxes" || q.type === "image_multiselect") && Array.isArray(val)) {
    const labels = val
      .map((id) => q.options?.find((o: any) => o.id === id)?.label || id)
      .filter(Boolean);
    return labels.join(", ") || "(No answer)";
  }
  if (q.type === "full_name" && typeof val === "object") {
    return `${val.firstName || ""} ${val.lastName || ""}`.trim() || "(No answer)";
  }
  if (q.type === "address" && typeof val === "object") {
    const parts = [val.street, val.city, val.state, val.zip].filter(Boolean);
    return parts.join(", ") || "(No answer)";
  }
  if (q.type === "choice_matrix" && typeof val === "object") {
    return Object.entries(val)
      .map(([row, col]) => `${row}: ${col}`)
      .join(" | ");
  }
  if (q.type === "ranking" && Array.isArray(val)) {
    return val.map((item, idx) => `${idx + 1}. ${item}`).join(", ");
  }
  if (q.type === "thumbs") {
    return val === "up" ? "👍 Thumbs Up" : val === "down" ? "👎 Thumbs Down" : String(val);
  }
  if (q.type === "terms") {
    return val ? "✓ Accepted Terms" : "Not Accepted";
  }
  if (q.type === "emoji_rating") {
    const emojis: Record<number, string> = { 1: "😠 Very Dissatisfied", 2: "🙁 Dissatisfied", 3: "😐 Neutral", 4: "🙂 Satisfied", 5: "😀 Very Satisfied" };
    return emojis[Number(val)] || `${val} Stars`;
  }
  if (typeof val === "object") {
    return JSON.stringify(val);
  }
  return String(val);
}
