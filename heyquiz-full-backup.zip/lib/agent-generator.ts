import { FormSchemaType, Question, OutcomeTier } from "./schema";
import { nanoid } from "nanoid";

export interface AgentGenerateRequest {
  prompt?: string;
  topic?: string;
  numQuestions?: number;
  difficulty?: "beginner" | "intermediate" | "advanced";
  mode?: "quiz" | "survey";
  timerMinutes?: number;
}

export function generateQuizWithAgent(req: AgentGenerateRequest): FormSchemaType {
  const topic = req.topic || req.prompt || "Web Development & Architecture";
  const numQuestions = Math.min(Math.max(req.numQuestions || 5, 2), 15);
  const difficulty = req.difficulty || "intermediate";
  const isSurvey = req.mode === "survey";

  const formId = `quiz-${nanoid(8)}`;
  const title = generateSmartTitle(topic, isSurvey);

  const questions: Question[] = [];

  const lowerTopic = topic.toLowerCase();

  if (lowerTopic.includes("python") || lowerTopic.includes("asyncio") || lowerTopic.includes("backend")) {
    questions.push(
      {
        id: `q-${nanoid(6)}`,
        type: "multiple_choice",
        title: "What is the primary role of the event loop in Python's asyncio module?",
        description: "Focus on cooperative multitasking and I/O scheduling.",
        required: true,
        points: 20,
        options: [
          { id: nanoid(4), label: "It schedules and executes asynchronous tasks and handles I/O events cooperatively on a single thread.", isCorrect: true, explanation: "asyncio uses a single-threaded cooperative event loop to multiplex socket and I/O events without thread context-switching overhead." },
          { id: nanoid(4), label: "It compiles Python bytecode to native C machine instructions.", isCorrect: false },
          { id: nanoid(4), label: "It spawns a new OS kernel thread for every async function call.", isCorrect: false },
          { id: nanoid(4), label: "It manages garbage collection for circular object references.", isCorrect: false },
        ],
        explanation: "The event loop is the engine that drives asyncio coroutines by running tasks until they await an I/O operation.",
      },
      {
        id: `q-${nanoid(6)}`,
        type: "switch",
        title: "True or False: Calling a synchronous CPU-bound blocking function directly inside an async def function blocks the entire event loop.",
        required: true,
        points: 20,
        options: [
          { id: "true", label: "True", isCorrect: true, explanation: "Because Python's event loop runs in a single thread, blocking calls halt all other pending coroutines. Use asyncio.to_thread() instead." },
          { id: "false", label: "False", isCorrect: false, explanation: "It does block! To avoid blocking, delegate CPU-bound work to an executor or asyncio.to_thread." },
        ],
        explanation: "Blocking calls in async code freeze the event loop for all concurrent connections.",
      },
      {
        id: `q-${nanoid(6)}`,
        type: "multiselect",
        title: "Which of the following are valid ways to run multiple coroutines concurrently in Python?",
        description: "Select all that apply.",
        required: true,
        points: 20,
        options: [
          { id: nanoid(4), label: "asyncio.gather(*tasks)", isCorrect: true, explanation: "gather() runs awaitable objects concurrently and aggregates their return values." },
          { id: nanoid(4), label: "asyncio.TaskGroup() (Python 3.11+)", isCorrect: true, explanation: "TaskGroup provides modern structured concurrency with automatic cleanup on failure." },
          { id: nanoid(4), label: "asyncio.create_task()", isCorrect: true, explanation: "create_task schedules coroutines immediately on the event loop." },
          { id: nanoid(4), label: "async.concurrent_map()", isCorrect: false, explanation: "There is no async.concurrent_map in Python's standard library." },
        ],
        explanation: "asyncio.gather, TaskGroup, and create_task are the canonical concurrency primitives in Python.",
      },
      {
        id: `q-${nanoid(6)}`,
        type: "short_answer",
        title: "In Python 3.11+, what context manager class introduced modern Structured Concurrency?",
        description: "Two words, PascalCase (e.g. TaskGroup).",
        required: true,
        points: 20,
        correctAnswerText: "TaskGroup",
        placeholder: "e.g. TaskGroup",
        explanation: "async with asyncio.TaskGroup() as tg: ... guarantees that if one task fails, remaining tasks are safely cancelled.",
      }
    );
  } else if (lowerTopic.includes("docker") || lowerTopic.includes("kubernetes") || lowerTopic.includes("devops") || lowerTopic.includes("cloud")) {
    questions.push(
      {
        id: `q-${nanoid(6)}`,
        type: "multiple_choice",
        title: "What is the primary difference between a Docker container and a Virtual Machine?",
        required: true,
        points: 25,
        options: [
          { id: nanoid(4), label: "Containers share the host OS kernel and isolate processes via namespaces and cgroups, while VMs run full guest OS kernels on a hypervisor.", isCorrect: true },
          { id: nanoid(4), label: "Containers are always written in Go, whereas VMs are written in C++.", isCorrect: false },
          { id: nanoid(4), label: "VMs cannot have private IP addresses.", isCorrect: false },
        ],
        explanation: "Containers are lightweight process isolations sharing the host kernel, yielding fast startup and minimal RAM footprint.",
      },
      {
        id: `q-${nanoid(6)}`,
        type: "multiselect",
        title: "Which Linux kernel primitives form the bedrock of container isolation in Docker?",
        required: true,
        points: 25,
        options: [
          { id: nanoid(4), label: "Namespaces (PID, NET, IPC, MNT, UTS)", isCorrect: true, explanation: "Namespaces provide isolation of system resources." },
          { id: nanoid(4), label: "cgroups (Control Groups)", isCorrect: true, explanation: "cgroups limit and meter CPU, memory, and I/O resources." },
          { id: nanoid(4), label: "Chroot / pivot_root", isCorrect: true, explanation: "Isolates the root filesystem view." },
          { id: nanoid(4), label: "X11 Display Server", isCorrect: false, explanation: "X11 is a windowing system, not a container isolation primitive." },
        ],
        explanation: "Namespaces isolate what processes can see; cgroups restrict how much resources they can use.",
      }
    );
  } else {
    questions.push(
      {
        id: `q-${nanoid(6)}`,
        type: "multiple_choice",
        title: `What is a core best practice when architecting solutions for: ${topic}?`,
        description: `Consider scalability, resilience, and maintainability.`,
        required: true,
        points: 20,
        options: [
          { id: nanoid(4), label: "Decouple components, use deterministic declarative schemas, and maintain clear isolation boundaries.", isCorrect: true, explanation: "Decoupled architectures with explicit contracts are easier to test, scale, and iterate on." },
          { id: nanoid(4), label: "Bundle all business logic into a single monolithic script with global state.", isCorrect: false, explanation: "Global mutable state causes unpredictable regressions and concurrency bugs." },
          { id: nanoid(4), label: "Disable logging and telemetry in production to save CPU cycles.", isCorrect: false, explanation: "Observability and structured logging are critical in production systems." },
          { id: nanoid(4), label: "Hardcode credentials and configuration values directly in git.", isCorrect: false, explanation: "Secrets must be securely managed via environment variables or secret vaults." },
        ],
        explanation: "Loose coupling with strict schema contracts ensures system resilience and painless refactoring.",
      },
      {
        id: `q-${nanoid(6)}`,
        type: "switch",
        title: `True or False: In modern software design, declarative specifications are generally preferred over imperative procedures for agentic systems.`,
        required: true,
        points: 20,
        options: [
          { id: "true", label: "True", isCorrect: true, explanation: "Declarative schemas let AI models reason about the target state while allowing the runtime engine to optimize execution." },
          { id: "false", label: "False", isCorrect: false, explanation: "Declarative formats like JSON Schema and OpenAPI are far superior for LLM tool calling." },
        ],
        explanation: "Declarative models provide deterministic contracts that both humans and AI agents can validate easily.",
      },
      {
        id: `q-${nanoid(6)}`,
        type: "multiselect",
        title: `Which principles contribute to optimal system performance and user experience?`,
        description: "Select all that apply.",
        required: true,
        points: 20,
        options: [
          { id: nanoid(4), label: "Sub-100ms interaction latency with optimistic UI updates", isCorrect: true, explanation: "Snappy UI transitions feel instantaneous and boost user satisfaction." },
          { id: nanoid(4), label: "Comprehensive validation at both client and server boundaries", isCorrect: true, explanation: "Prevents invalid state and improves security." },
          { id: nanoid(4), label: "Accessible keyboard navigation and clear visual hierarchy", isCorrect: true, explanation: "Ensures power users and all audiences can navigate smoothly." },
          { id: nanoid(4), label: "Blocking synchronous network calls on the main UI thread", isCorrect: false, explanation: "Blocking the main thread freezes the interface." },
        ],
        explanation: "Optimistic updates, multi-layer validation, and keyboard support form the core of great software.",
      },
      {
        id: `q-${nanoid(6)}`,
        type: "short_answer",
        title: "What 3-letter acronym represents the core data interchange format widely used for APIs and LLM tool calling?",
        description: "JavaScript Object Notation.",
        required: true,
        points: 20,
        correctAnswerText: "JSON",
        placeholder: "e.g. XML",
        explanation: "JSON is the universal standard for structured data transfer and tool schemas.",
      },
      {
        id: `q-${nanoid(6)}`,
        type: "opinion_scale",
        title: `How would you rate your current depth of knowledge in ${topic}?`,
        description: "1 = Just starting out, 5 = Subject Matter Expert",
        required: false,
        points: 10,
        minRating: 1,
        maxRating: 5,
        ratingLabels: { low: "Novice", high: "Authority" },
      }
    );
  }

  const finalQuestions = questions.slice(0, numQuestions);

  const outcomeTiers: OutcomeTier[] = [
    {
      id: "tier-gold",
      minScorePercent: 85,
      maxScorePercent: 100,
      badge: "🏆 Mastermind",
      title: "Mastery Level Achieved",
      message: `Outstanding! You have demonstrated exceptional mastery of ${topic}.`,
      ctaText: "Review Answer Key",
    },
    {
      id: "tier-silver",
      minScorePercent: 60,
      maxScorePercent: 84,
      badge: "🎯 Proficient",
      title: "Strong Performance",
      message: `Solid job! You understand the foundational concepts with just a few areas for fine-tuning.`,
      ctaText: "Review Explanations",
    },
    {
      id: "tier-bronze",
      minScorePercent: 0,
      maxScorePercent: 59,
      badge: "🌱 Apprentice",
      title: "Keep Building",
      message: `Good effort! Take some time to review the detailed explanations and retake the quiz.`,
      ctaText: "Retake Quiz",
    },
  ];

  return {
    id: formId,
    title,
    description: `Generated by QuizCraft Agent · Topic: ${topic} · Difficulty: ${difficulty}`,
    mode: isSurvey ? "survey" : "quiz",
    theme: {
      id: "fillout-light",
      primaryColor: "#4f46e5",
      accentColor: "#10b981",
      backgroundColor: "#f4f5f7",
      cardColor: "#ffffff",
      textColor: "#111827",
      font: "sans",
      layout: "step",
      borderRadius: "lg",
    },
    settings: {
      showProgressBar: true,
      shuffleQuestions: false,
      timerMinutes: req.timerMinutes || 0,
      passingScorePercentage: 70,
      feedbackMode: "end",
      showAnswerKeyOnFinish: true,
      allowRetake: true,
      enableKeyboardShortcuts: true,
    },
    questions: finalQuestions,
    outcomeTiers,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
}

function generateSmartTitle(topic: string, isSurvey: boolean): string {
  if (isSurvey) {
    return `${capitalize(topic)} Experience & Feedback`;
  }
  return `${capitalize(topic)} Knowledge Sprint`;
}

function capitalize(str: string): string {
  if (!str) return str;
  return str.charAt(0).toUpperCase() + str.slice(1);
}
