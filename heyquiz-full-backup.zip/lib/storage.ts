import fs from "fs";
import path from "path";
import { FormSchemaType, FormSchema, QuizSubmissionResult } from "./schema";
import { DEFAULT_FORMS } from "./default-forms";

const DATA_DIR = path.join(process.cwd(), "data");
const FORMS_FILE = path.join(DATA_DIR, "forms.json");

function ensureDataFile() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(FORMS_FILE)) {
    fs.writeFileSync(FORMS_FILE, JSON.stringify(DEFAULT_FORMS, null, 2), "utf-8");
  }
}

export function getAllForms(): FormSchemaType[] {
  try {
    ensureDataFile();
    const data = fs.readFileSync(FORMS_FILE, "utf-8");
    const parsed = JSON.parse(data);
    if (Array.isArray(parsed)) {
      return parsed;
    }
    return DEFAULT_FORMS;
  } catch (err) {
    console.error("Error reading forms:", err);
    return DEFAULT_FORMS;
  }
}

export function getFormById(id: string): FormSchemaType | null {
  const forms = getAllForms();
  return forms.find((f) => f.id === id) || null;
}

export function saveForm(form: FormSchemaType): FormSchemaType {
  ensureDataFile();
  const forms = getAllForms();
  const index = forms.findIndex((f) => f.id === form.id);
  const updatedForm = {
    ...form,
    updatedAt: new Date().toISOString(),
  };

  if (index >= 0) {
    forms[index] = updatedForm;
  } else {
    forms.unshift(updatedForm);
  }

  fs.writeFileSync(FORMS_FILE, JSON.stringify(forms, null, 2), "utf-8");
  return updatedForm;
}

export function deleteForm(id: string): boolean {
  ensureDataFile();
  const forms = getAllForms();
  const filtered = forms.filter((f) => f.id !== id);
  if (filtered.length !== forms.length) {
    fs.writeFileSync(FORMS_FILE, JSON.stringify(filtered, null, 2), "utf-8");
    return true;
  }
  return false;
}

// ---------------- SUBMISSIONS STORAGE ----------------

const SUBMISSIONS_FILE = path.join(DATA_DIR, "submissions.json");

function ensureSubmissionsFile() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(SUBMISSIONS_FILE)) {
    fs.writeFileSync(SUBMISSIONS_FILE, JSON.stringify([], null, 2), "utf-8");
  }
}

export function getAllSubmissions(): QuizSubmissionResult[] {
  try {
    ensureSubmissionsFile();
    const data = fs.readFileSync(SUBMISSIONS_FILE, "utf-8");
    const parsed = JSON.parse(data);
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.error("Error reading submissions:", err);
    return [];
  }
}

export function getSubmissionsByFormId(formId: string): QuizSubmissionResult[] {
  const all = getAllSubmissions();
  return all
    .filter((s) => s.formId === formId)
    .sort((a, b) => new Date(b.submittedAt).getTime() - new Date(a.submittedAt).getTime());
}

export function saveSubmission(submission: QuizSubmissionResult): QuizSubmissionResult {
  ensureSubmissionsFile();
  const all = getAllSubmissions();
  const newSubmission: QuizSubmissionResult = {
    ...submission,
    id: submission.id || `sub-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    submittedAt: submission.submittedAt || new Date().toISOString(),
  };
  all.unshift(newSubmission);
  fs.writeFileSync(SUBMISSIONS_FILE, JSON.stringify(all, null, 2), "utf-8");
  return newSubmission;
}

export function deleteSubmission(submissionId: string): boolean {
  ensureSubmissionsFile();
  const all = getAllSubmissions();
  const filtered = all.filter((s) => s.id !== submissionId);
  if (filtered.length !== all.length) {
    fs.writeFileSync(SUBMISSIONS_FILE, JSON.stringify(filtered, null, 2), "utf-8");
    return true;
  }
  return false;
}

