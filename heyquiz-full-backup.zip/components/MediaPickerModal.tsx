import React, { useState } from "react";
import { X, UploadCloud, Search, Link as LinkIcon, Image as ImageIcon, CheckCircle2 } from "lucide-react";

interface MediaPickerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelect: (url: string) => void;
  initialUrl?: string;
}

const MOCK_UNSPLASH = [
  "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=600&q=80", // Beach
  "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=600&q=80", // Mountains
  "https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=600&q=80", // Forest
  "https://images.unsplash.com/photo-1493246507139-91e8fad9978e?auto=format&fit=crop&w=600&q=80", // Lake
  "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=600&q=80", // Tech meeting
  "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=600&q=80", // Data/Code
  "https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=600&q=80", // Team
  "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=600&q=80", // Earth/Space
  "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=600&q=80", // Servers
  "https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&w=600&q=80", // Monolith/Building
  "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=600&q=80", // Office
  "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=600&q=80", // Architecture
];

export default function MediaPickerModal({ isOpen, onClose, onSelect, initialUrl }: MediaPickerModalProps) {
  const [activeTab, setActiveTab] = useState<"unsplash" | "upload" | "url">("unsplash");
  const [searchQuery, setSearchQuery] = useState("");
  const [urlInput, setUrlInput] = useState(initialUrl || "");
  const [selectedMock, setSelectedMock] = useState<string | null>(initialUrl || null);

  if (!isOpen) return null;

  const handleSelect = (url: string) => {
    onSelect(url);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div 
        className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl overflow-hidden flex flex-col"
        style={{ maxHeight: '85vh' }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
          <h2 className="text-lg font-bold text-gray-900">Select Image</h2>
          <button 
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-full transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex items-center px-6 pt-2 border-b border-gray-100 gap-6">
          <button
            onClick={() => setActiveTab("unsplash")}
            className={`pb-3 text-sm font-semibold border-b-2 transition cursor-pointer ${
              activeTab === "unsplash" ? "border-indigo-600 text-indigo-600" : "border-transparent text-gray-500 hover:text-gray-800"
            }`}
          >
            <span className="flex items-center gap-2"><ImageIcon className="w-4 h-4" /> Unsplash</span>
          </button>
          <button
            onClick={() => setActiveTab("upload")}
            className={`pb-3 text-sm font-semibold border-b-2 transition cursor-pointer ${
              activeTab === "upload" ? "border-indigo-600 text-indigo-600" : "border-transparent text-gray-500 hover:text-gray-800"
            }`}
          >
            <span className="flex items-center gap-2"><UploadCloud className="w-4 h-4" /> Upload</span>
          </button>
          <button
            onClick={() => setActiveTab("url")}
            className={`pb-3 text-sm font-semibold border-b-2 transition cursor-pointer ${
              activeTab === "url" ? "border-indigo-600 text-indigo-600" : "border-transparent text-gray-500 hover:text-gray-800"
            }`}
          >
            <span className="flex items-center gap-2"><LinkIcon className="w-4 h-4" /> From URL</span>
          </button>
        </div>

        {/* Content Area */}
        <div className="p-6 overflow-y-auto flex-1 bg-gray-50/50">
          
          {activeTab === "unsplash" && (
            <div className="space-y-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input 
                  type="text" 
                  placeholder="Search Unsplash for high-resolution photos..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition"
                />
              </div>
              
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                {MOCK_UNSPLASH.map((url, i) => (
                  <div 
                    key={i}
                    onClick={() => setSelectedMock(url)}
                    className={`relative aspect-video rounded-xl overflow-hidden cursor-pointer group border-2 transition ${
                      selectedMock === url ? "border-indigo-600 shadow-md" : "border-transparent hover:border-gray-300"
                    }`}
                  >
                    <img src={url} alt="Unsplash mock" className="w-full h-full object-cover transition duration-500 group-hover:scale-110" />
                    {selectedMock === url && (
                      <div className="absolute inset-0 bg-indigo-600/20 flex items-center justify-center">
                        <div className="bg-indigo-600 text-white rounded-full p-1 shadow-sm">
                          <CheckCircle2 className="w-5 h-5" />
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === "upload" && (
            <div className="h-full min-h-[300px] flex flex-col items-center justify-center border-2 border-dashed border-gray-300 rounded-2xl bg-white hover:bg-gray-50 hover:border-indigo-400 transition cursor-pointer">
              <div className="w-16 h-16 bg-indigo-50 text-indigo-600 rounded-full flex items-center justify-center mb-4">
                <UploadCloud className="w-8 h-8" />
              </div>
              <h3 className="text-base font-bold text-gray-900 mb-1">Click or drag image to upload</h3>
              <p className="text-sm text-gray-500">Supports JPG, PNG, WEBP, GIF up to 10MB</p>
            </div>
          )}

          {activeTab === "url" && (
            <div className="space-y-4 max-w-xl mx-auto pt-8">
              <label className="block text-sm font-semibold text-gray-700">Paste Image URL</label>
              <div className="flex gap-3">
                <input 
                  type="url" 
                  placeholder="https://..."
                  value={urlInput}
                  onChange={(e) => setUrlInput(e.target.value)}
                  className="flex-1 px-4 py-2.5 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition"
                />
              </div>
              {urlInput && (
                <div className="mt-6 border border-gray-200 rounded-xl overflow-hidden bg-white p-2 shadow-sm">
                  <div className="text-xs text-gray-500 font-semibold mb-2 px-2 pt-1">Preview</div>
                  <img src={urlInput} alt="Preview" className="w-full h-auto max-h-64 object-contain rounded-lg" onError={(e) => (e.currentTarget.style.display = 'none')} />
                </div>
              )}
            </div>
          )}

        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 border-t border-gray-100 flex items-center justify-end gap-3 bg-white">
          <button 
            onClick={onClose}
            className="px-5 py-2.5 text-sm font-semibold text-gray-700 hover:bg-gray-100 rounded-xl transition cursor-pointer"
          >
            Cancel
          </button>
          <button 
            onClick={() => {
              if (activeTab === "unsplash" && selectedMock) handleSelect(selectedMock);
              if (activeTab === "url" && urlInput) handleSelect(urlInput);
              if (activeTab === "upload") alert("Upload simulation only. Use Unsplash or URL tab for now.");
            }}
            disabled={(activeTab === "unsplash" && !selectedMock) || (activeTab === "url" && !urlInput)}
            className="px-5 py-2.5 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
          >
            Insert Image
          </button>
        </div>
      </div>
    </div>
  );
}
