"use client";

import React, { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import confetti from "canvas-confetti";
import {
  FormSchemaType,
  Question,
  QuizSubmissionResult,
  LogicRule,
  LogicOperator,
} from "@/lib/schema";
import {
  CheckCircle2,
  XCircle,
  Clock,
  ArrowRight,
  ArrowLeft,
  RotateCcw,
  Share2,
  Trophy,
  Check,
  Edit3,
  UploadCloud,
  PenTool,
  Calendar,
  SlidersHorizontal,
  Sparkles,
  FileText,
  ThumbsUp,
  ThumbsDown,
  Smile,
  ExternalLink,
  Lock,
  Eye,
  EyeOff,
  Globe,
  DollarSign,
  ChevronUp,
  ChevronDown,
  User,
  MapPin,
  Palette,
  Image as ImageIcon,
  Heart,
  HeartCrack,
  Mic,
  Square,
  Video,
  Calculator,
  ShieldCheck,
  CalendarDays,
  ListCollapse,
  LayoutTemplate,
  CheckSquare,
  Volume2,
  Play as PlayIcon,
} from "lucide-react";
import Link from "next/link";

interface QuizPlayerProps {
  form: FormSchemaType;
}

export default function QuizPlayer({ form }: QuizPlayerProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [history, setHistory] = useState<number[]>([0]);
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [immediateFeedback, setImmediateFeedback] = useState<{
    submitted: boolean;
    isCorrect: boolean;
    explanation?: string;
  } | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [result, setResult] = useState<QuizSubmissionResult | null>(null);
  const [showAnswerReview, setShowAnswerReview] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [requiredError, setRequiredError] = useState<string | null>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [hasStartedCover, setHasStartedCover] = useState(() => !(form.coverPage?.enabled));
  const [isReviewing, setIsReviewing] = useState(false);
  const [expandedAccordions, setExpandedAccordions] = useState<Record<string, boolean>>({});
  const [isRecordingAudio, setIsRecordingAudio] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);

  // Timer logic
  const [secondsRemaining, setSecondsRemaining] = useState<number | null>(() => {
    return form.settings.timerMinutes && form.settings.timerMinutes > 0
      ? form.settings.timerMinutes * 60
      : null;
  });

  const questions = form.questions || [];
  const totalQuestions = questions.length;
  const currentQ: Question | undefined = questions[currentIndex];

  const formPages = form.pages && form.pages.length > 0
    ? form.pages
    : [{ id: "page-1", title: "Page 1", questionIds: questions.map((q) => q.id) }];

  const qPageId = currentQ?.pageId || formPages[0].id;
  const currentPageIndex = Math.max(0, formPages.findIndex((p) => p.id === qPageId));
  const currentPage = formPages[currentPageIndex] || formPages[0];

  useEffect(() => {
    let interval: any;
    if (isRecordingAudio) {
      interval = setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRecordingAudio]);

  // Logic condition evaluator helper
  const evaluateCondition = useCallback(
    (
      operator: LogicOperator,
      actualValue: any,
      targetValue?: string,
      question?: Question
    ): boolean => {
      if (operator === "is_answered") {
        if (actualValue === undefined || actualValue === null || actualValue === "") return false;
        if (Array.isArray(actualValue) && actualValue.length === 0) return false;
        return true;
      }
      if (operator === "is_not_answered") {
        if (actualValue === undefined || actualValue === null || actualValue === "") return true;
        if (Array.isArray(actualValue) && actualValue.length === 0) return true;
        return false;
      }

      let actualStr = "";
      if (actualValue !== undefined && actualValue !== null) {
        if (typeof actualValue === "object" && !Array.isArray(actualValue)) {
          actualStr = JSON.stringify(actualValue);
        } else {
          actualStr = String(actualValue).trim().toLowerCase();
        }
      }

      const targetStr = (targetValue ?? "").trim().toLowerCase();

      let matchedOptionLabel = "";
      if (question?.options && typeof actualValue === "string") {
        const opt = question.options.find((o) => o.id === actualValue);
        if (opt) {
          matchedOptionLabel = opt.label.trim().toLowerCase();
        }
      }

      // Check array of selected options (multiselect/checkboxes)
      if (Array.isArray(actualValue)) {
        const labels = actualValue
          .map((id) => question?.options?.find((o) => o.id === id)?.label.trim().toLowerCase() || String(id).toLowerCase());
        if (operator === "equals" || operator === "contains") {
          return labels.some((l) => l === targetStr || l.includes(targetStr));
        }
        if (operator === "not_equals") {
          return !labels.some((l) => l === targetStr);
        }
      }

      switch (operator) {
        case "equals":
          return (
            actualStr === targetStr ||
            (matchedOptionLabel !== "" && matchedOptionLabel === targetStr)
          );
        case "not_equals":
          return (
            actualStr !== targetStr &&
            (matchedOptionLabel === "" || matchedOptionLabel !== targetStr)
          );
        case "contains":
          return (
            actualStr.includes(targetStr) ||
            (matchedOptionLabel !== "" && matchedOptionLabel.includes(targetStr))
          );
        case "greater_than": {
          const numAct = parseFloat(actualStr);
          const numTgt = parseFloat(targetStr);
          return !isNaN(numAct) && !isNaN(numTgt) && numAct > numTgt;
        }
        case "less_than": {
          const numAct = parseFloat(actualStr);
          const numTgt = parseFloat(targetStr);
          return !isNaN(numAct) && !isNaN(numTgt) && numAct < numTgt;
        }
        default:
          return false;
      }
    },
    []
  );

  // Submit quiz function
  const handleFinalSubmit = useCallback(
    async (finalAnswers: Record<string, any>, forcedTierId?: string) => {
      setIsSubmitting(true);
      try {
        const res = await fetch(`/api/forms/${form.id}/submit`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ answers: finalAnswers, forcedTierId }),
        });
        const data = await res.json();
        setResult(data);

        // Fire celebratory confetti if passed
        if (data.passed) {
          confetti({
            particleCount: 100,
            spread: 70,
            origin: { y: 0.6 },
          });
        }
      } catch (err) {
        console.error("Submission failed:", err);
      } finally {
        setIsSubmitting(false);
      }
    },
    [form.id]
  );

  // Countdown timer effect
  useEffect(() => {
    if (secondsRemaining === null || result) return;
    if (secondsRemaining <= 0) {
      handleFinalSubmit(answers);
      return;
    }
    const interval = setInterval(() => {
      setSecondsRemaining((prev) => (prev !== null && prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(interval);
  }, [secondsRemaining, result, handleFinalSubmit, answers]);

  // Next target calculation based on active logic rules
  const calculateNext = useCallback(
    (
      fromIdx: number,
      currentAnswers: Record<string, any>
    ): { type: "question"; index: number } | { type: "ending"; forcedTierId?: string } => {
      const current = questions[fromIdx];
      if (!current) return { type: "ending" };

      // 1. Direct rule matches on current question
      const rules = (form.logicRules || []).filter(
        (r) => r.sourceQuestionId === current.id
      );

      for (const rule of rules) {
        const val = currentAnswers[current.id];
        if (evaluateCondition(rule.operator, val, rule.value, current)) {
          if (rule.action === "jump_to_question" && rule.targetQuestionId) {
            const targetIdx = questions.findIndex(
              (q) => q.id === rule.targetQuestionId
            );
            if (targetIdx !== -1) {
              return { type: "question", index: targetIdx };
            }
          }
          if (rule.action === "jump_to_ending") {
            return {
              type: "ending",
              forcedTierId:
                rule.targetOutcomeTierId !== "default"
                  ? rule.targetOutcomeTierId
                  : undefined,
            };
          }
        }
      }

      // 2. Compute hidden question IDs across all current answers
      const hiddenIds = new Set<string>();
      for (const rule of form.logicRules || []) {
        const srcQ = questions.find((q) => q.id === rule.sourceQuestionId);
        if (!srcQ) continue;
        const val = currentAnswers[srcQ.id];
        if (
          val !== undefined &&
          evaluateCondition(rule.operator, val, rule.value, srcQ)
        ) {
          if (rule.action === "hide_question" && rule.targetQuestionId) {
            hiddenIds.add(rule.targetQuestionId);
          }
        }
      }

      // 3. Find next question that is not hidden
      for (let i = fromIdx + 1; i < questions.length; i++) {
        if (!hiddenIds.has(questions[i].id)) {
          return { type: "question", index: i };
        }
      }

      return { type: "ending" };
    },
    [form.logicRules, questions, evaluateCondition]
  );

  const goToNext = useCallback(() => {
    setImmediateFeedback(null);
    if (
      currentQ &&
      currentQ.required &&
      currentQ.type !== "heading" &&
      currentQ.type !== "subheading" &&
      currentQ.type !== "banner" &&
      currentQ.type !== "divider" &&
      currentQ.type !== "image_display" &&
      currentQ.type !== "rich_text" &&
      currentQ.type !== "accordion" &&
      currentQ.type !== "hidden"
    ) {
      const val = answers[currentQ.id];
      let isEmpty =
        val === undefined ||
        val === null ||
        val === "" ||
        (Array.isArray(val) && val.length === 0);

      if (currentQ.type === "full_name" && typeof val === "object") {
        isEmpty = !val.firstName?.trim() && !val.lastName?.trim();
      } else if (currentQ.type === "terms") {
        isEmpty = val !== true;
      } else if (currentQ.type === "checkbox") {
        isEmpty = val !== true;
      } else if (currentQ.type === "captcha") {
        isEmpty = val !== true;
      } else if (currentQ.type === "choice_matrix" && typeof val === "object") {
        const requiredRows = currentQ.rows || [];
        isEmpty = requiredRows.some((r) => !val[r]);
      } else if (currentQ.type === "matrix_multiselect" && typeof val === "object") {
        const requiredRows = currentQ.rows || [];
        isEmpty = requiredRows.some((r) => !val[r] || val[r].length === 0);
      }

      if (isEmpty) {
        setRequiredError("Please answer this required question to continue.");
        return;
      }
    }
    setRequiredError(null);
    const next = calculateNext(currentIndex, answers);
    if (next.type === "question") {
      setHistory((prev) => [...prev, next.index]);
      setCurrentIndex(next.index);
    } else {
      if (form.settings.showReviewBeforeSubmit && !isReviewing) {
        setIsReviewing(true);
      } else {
        handleFinalSubmit(answers, next.forcedTierId);
      }
    }
  }, [currentIndex, answers, calculateNext, handleFinalSubmit, currentQ, form.settings.showReviewBeforeSubmit, isReviewing]);

  const goToPrev = () => {
    setImmediateFeedback(null);
    setRequiredError(null);
    if (isReviewing) {
      setIsReviewing(false);
      return;
    }
    if (history.length > 1) {
      const nextHistory = [...history];
      nextHistory.pop();
      const prevIdx = nextHistory[nextHistory.length - 1];
      setHistory(nextHistory);
      setCurrentIndex(prevIdx);
    } else if (currentIndex > 0) {
      setCurrentIndex((prev) => prev - 1);
    }
  };

  const handleSelectAnswer = (qId: string, val: any) => {
    setRequiredError(null);
    const updated = { ...answers, [qId]: val };
    setAnswers(updated);

    // Immediate feedback check
    if (
      form.mode === "quiz" &&
      form.settings.feedbackMode === "immediate" &&
      currentQ &&
      (currentQ.type === "multiple_choice" || currentQ.type === "switch" || currentQ.type === "picture_choice" || currentQ.type === "like_dislike")
    ) {
      const correctOpt = currentQ.options?.find((o) => o.isCorrect);
      const isCorrect = correctOpt ? correctOpt.id === val : false;
      const selectedOpt = currentQ.options?.find((o) => o.id === val);
      setImmediateFeedback({
        submitted: true,
        isCorrect,
        explanation: selectedOpt?.explanation || currentQ.explanation,
      });
      return;
    }

    // Auto-advance for single select
    if (
      currentQ &&
      (currentQ.type === "multiple_choice" || currentQ.type === "switch" || currentQ.type === "picture_choice" || currentQ.type === "like_dislike")
    ) {
      setTimeout(() => {
        const next = calculateNext(currentIndex, updated);
        if (next.type === "question") {
          setHistory((prev) => [...prev, next.index]);
          setCurrentIndex(next.index);
        } else {
          if (form.settings.showReviewBeforeSubmit && !isReviewing) {
            setIsReviewing(true);
          } else {
            handleFinalSubmit(updated, next.forcedTierId);
          }
        }
      }, 250);
    }
  };

  const handleMultiSelectToggle = (qId: string, optionId: string) => {
    const currentList: string[] = Array.isArray(answers[qId]) ? answers[qId] : [];
    let nextList: string[];
    if (currentList.includes(optionId)) {
      nextList = currentList.filter((id) => id !== optionId);
    } else {
      nextList = [...currentList, optionId];
    }
    setAnswers({ ...answers, [qId]: nextList });
  };

  // Keyboard navigation
  useEffect(() => {
    if (!form.settings.enableKeyboardShortcuts || result || isSubmitting) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (target.tagName === "INPUT" || target.tagName === "TEXTAREA") {
        if (e.key === "Enter" && !e.shiftKey) {
          e.preventDefault();
          goToNext();
        }
        return;
      }

      if (e.key === "Enter") {
        e.preventDefault();
        goToNext();
        return;
      }

      if (e.key === "ArrowLeft" || (e.key === "Backspace" && !target.closest("input"))) {
        if (currentIndex > 0) {
          e.preventDefault();
          goToPrev();
          return;
        }
      }

      if (
        currentQ &&
        (currentQ.type === "multiple_choice" || currentQ.type === "switch" || currentQ.type === "picture_choice")
      ) {
        let optIdx = -1;
        const num = parseInt(e.key, 10);
        if (!isNaN(num) && currentQ.options && num >= 1 && num <= currentQ.options.length) {
          optIdx = num - 1;
        } else if (e.key.length === 1 && currentQ.options) {
          const charCode = e.key.toUpperCase().charCodeAt(0);
          if (charCode >= 65 && charCode <= 90) {
            const letterIdx = charCode - 65;
            if (letterIdx < currentQ.options.length) {
              optIdx = letterIdx;
            }
          }
        }

        if (optIdx >= 0 && currentQ.options && currentQ.options[optIdx]) {
          e.preventDefault();
          handleSelectAnswer(currentQ.id, currentQ.options[optIdx].id);
        }
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [form.settings.enableKeyboardShortcuts, result, isSubmitting, currentQ, currentIndex, goToNext]);

  const copyShareLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const retakeQuiz = () => {
    setAnswers({});
    setResult(null);
    setCurrentIndex(0);
    setImmediateFeedback(null);
    if (form.settings.timerMinutes && form.settings.timerMinutes > 0) {
      setSecondsRemaining(form.settings.timerMinutes * 60);
    }
  };

  const progressPercent = totalQuestions > 0 ? Math.round(((currentIndex + 1) / totalQuestions) * 100) : 100;

  const formatTimer = (totalSec: number) => {
    const mins = Math.floor(totalSec / 60);
    const secs = totalSec % 60;
    return `${mins}:${secs < 10 ? "0" : ""}${secs}`;
  };

  // 1. OUTCOME / RESULTS VIEW (FILLOUT LIGHT STYLE)
  if (result) {
    const isPassing = result.passed;
    return (
      <div className="min-h-screen bg-[#f4f5f7] text-gray-900 flex flex-col items-center justify-center p-4 sm:p-8 font-sans">
        <motion.div
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.25 }}
          className="w-full max-w-2xl bg-white border border-gray-200/90 rounded-2xl p-6 sm:p-10 shadow-lg"
        >
          <div className="text-center space-y-4">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-indigo-50 border border-indigo-100 text-indigo-600 mb-1">
              <Trophy className="w-8 h-8" />
            </div>

            <div className="inline-block px-3 py-1 rounded-full text-xs font-semibold tracking-wide bg-gray-100 text-gray-700">
              {result.matchedTier?.badge || (isPassing ? "Passed" : "Completed")}
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-gray-900">
              {result.matchedTier?.title || (isPassing ? "Great Job!" : "Quiz Completed")}
            </h1>

            <p className="text-gray-600 text-sm max-w-lg mx-auto">
              {result.matchedTier?.message ||
                `You completed ${result.totalQuestions} questions with a score of ${result.percentageScore}%.`}
            </p>

            {/* Score Ring Stat */}
            <div className="py-4 flex items-center justify-center gap-4">
              <div className="bg-gray-50 border border-gray-200 rounded-xl p-4 text-center min-w-[130px]">
                <div className="text-3xl font-black text-indigo-600">
                  {result.percentageScore}%
                </div>
                <div className="text-[11px] uppercase tracking-wider text-gray-400 font-semibold mt-1">
                  Final Score
                </div>
              </div>

              <div className="bg-gray-50 border border-gray-200 rounded-xl p-4 text-center min-w-[130px]">
                <div className="text-3xl font-black text-emerald-600">
                  {result.totalPointsEarned}
                  <span className="text-sm text-gray-400 font-normal">
                    /{result.totalPointsPossible}
                  </span>
                </div>
                <div className="text-[11px] uppercase tracking-wider text-gray-400 font-semibold mt-1">
                  Points Earned
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center justify-center gap-3 pt-3">
              {form.settings.allowRetake && (
                <button
                  onClick={retakeQuiz}
                  className="px-4 py-2 rounded-lg bg-white hover:bg-gray-50 text-gray-700 text-xs font-semibold flex items-center gap-2 border border-gray-300 shadow-xs transition"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Retake Quiz</span>
                </button>
              )}

              <button
                onClick={copyShareLink}
                className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold flex items-center gap-2 transition shadow-xs"
              >
                {copiedLink ? <Check className="w-3.5 h-3.5" /> : <Share2 className="w-3.5 h-3.5" />}
                <span>{copiedLink ? "Link Copied!" : "Share Quiz"}</span>
              </button>

              <Link
                href={`/editor/${form.id}`}
                className="px-4 py-2 rounded-lg bg-white hover:bg-gray-50 text-gray-700 text-xs font-semibold flex items-center gap-2 border border-gray-300 shadow-xs transition"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Open Editor</span>
              </Link>
            </div>
          </div>

          {/* Answer Key & Explanations Accordion */}
          {form.settings.showAnswerKeyOnFinish && (
            <div className="mt-8 pt-6 border-t border-gray-100">
              <button
                onClick={() => setShowAnswerReview(!showAnswerReview)}
                className="w-full flex items-center justify-between text-left text-xs font-bold text-gray-700 hover:text-gray-900 transition py-1"
              >
                <span>Review Answers & Explanations ({result.grading.length})</span>
                <span className="text-indigo-600 text-xs font-semibold">
                  {showAnswerReview ? "Hide Details" : "Show Details"}
                </span>
              </button>

              {showAnswerReview && (
                <div className="mt-4 space-y-3">
                  {result.grading.map((item, idx) => (
                    <div
                      key={item.questionId}
                      className={`p-4 rounded-xl border ${
                        item.isCorrect
                          ? "bg-emerald-50/50 border-emerald-200"
                          : "bg-rose-50/50 border-rose-200"
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        {item.isCorrect ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                        ) : (
                          <XCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                        )}
                        <div className="space-y-1 flex-1 text-xs">
                          <div className="font-semibold text-gray-900">
                            {idx + 1}. {item.questionTitle}
                          </div>
                          <div className="text-gray-600">
                            Your answer:{" "}
                            <span className={item.isCorrect ? "text-emerald-700 font-medium" : "text-rose-700 font-medium"}>
                              {item.userAnswer}
                            </span>
                          </div>
                          {!item.isCorrect && (
                            <div className="text-gray-600">
                              Correct answer:{" "}
                              <span className="text-emerald-700 font-semibold">
                                {item.correctAnswer}
                              </span>
                            </div>
                          )}
                          {item.explanation && (
                            <div className="text-gray-600 mt-2 bg-white/80 p-2 rounded-lg border border-gray-200">
                              💡 <span className="font-semibold text-gray-800">Explanation:</span>{" "}
                              {item.explanation}
                            </div>
                          )}
                        </div>
                        <div className="text-[11px] font-bold text-gray-500 font-mono">
                          {item.earnedPoints}/{item.maxPoints} pts
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </motion.div>
      </div>
    );
  }

  // 1b. COVER / WELCOME PAGE HERO SCREEN
  if (form.coverPage?.enabled && !hasStartedCover) {
    return (
      <div
        className="min-h-screen flex flex-col items-center justify-center p-4 sm:p-8 font-sans"
        style={{ backgroundColor: form.theme?.backgroundColor || "#f4f5f7" }}
      >
        <div className="w-full max-w-xl bg-white border border-gray-200/90 rounded-3xl overflow-hidden shadow-xl">
          {form.coverPage?.imageUrl && (
            <div className="w-full h-56 bg-gray-100 overflow-hidden relative">
              <img
                src={form.coverPage.imageUrl}
                alt="Cover Hero"
                className="w-full h-full object-cover"
              />
            </div>
          )}
          <div className="p-8 sm:p-10 text-center space-y-5">
            <div className="inline-flex p-3 rounded-2xl bg-indigo-50 text-indigo-600 mb-1 border border-indigo-100 shadow-xs">
              <LayoutTemplate className="w-8 h-8" />
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-gray-900 leading-snug">
              {form.coverPage?.title || form.title || "Welcome to the Assessment"}
            </h1>

            {form.coverPage?.subtitle && (
              <p className="text-gray-600 text-sm max-w-md mx-auto leading-relaxed">
                {form.coverPage.subtitle}
              </p>
            )}

            <div className="flex items-center justify-center gap-6 text-xs text-gray-500 font-mono py-2 border-y border-gray-100">
              <span className="flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-gray-400" />
                ~{form.coverPage?.estimatedMinutes || 3} min
              </span>
              <span>•</span>
              <span className="flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-gray-400" />
                {questions.length} questions
              </span>
            </div>

            <div className="pt-2">
              <button
                type="button"
                onClick={() => setHasStartedCover(true)}
                className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm shadow-md hover:shadow-lg transition cursor-pointer flex items-center justify-center gap-2 mx-auto"
              >
                <span>{form.coverPage?.buttonText || "Get Started"}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // 1c. PRE-SUBMIT REVIEW SCREEN (FILLOUT PARITY)
  if (isReviewing) {
    return (
      <div
        className="min-h-screen text-gray-900 flex flex-col justify-between font-sans selection:bg-indigo-500 selection:text-white"
        style={{ backgroundColor: form.theme?.backgroundColor || "#f4f5f7" }}
      >
        <header className="w-full border-b border-gray-200 bg-white sticky top-0 z-50 px-4 sm:px-8 py-3.5 flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-2">
            <Link href="/" className="flex items-center transition hover:opacity-85">
              <img src="/logo.png" alt="heyquiz" className="h-5.5 w-auto object-contain" />
            </Link>
            <span className="text-gray-300">/</span>
            <span className="text-xs font-semibold text-gray-700 truncate max-w-xs">
              Review Answers
            </span>
          </div>
        </header>

        <main className="flex-1 flex items-center justify-center p-4 sm:p-8 max-w-2xl w-full mx-auto">
          <div className="w-full bg-white rounded-2xl border border-gray-200/90 shadow-sm p-6 sm:p-8 space-y-6">
            <div className="border-b border-gray-100 pb-4">
              <h2 className="text-xl font-bold text-gray-900">Review Your Answers</h2>
              <p className="text-xs text-gray-500 mt-1">
                Please double-check your answers before final submission.
              </p>
            </div>

            <div className="space-y-3 max-h-[460px] overflow-y-auto pr-1">
              {questions.map((q, idx) => {
                if (
                  q.type === "heading" ||
                  q.type === "subheading" ||
                  q.type === "banner" ||
                  q.type === "divider" ||
                  q.type === "image_display" ||
                  q.type === "rich_text" ||
                  q.type === "accordion" ||
                  q.type === "hidden"
                ) {
                  return null;
                }
                const rawAns = answers[q.id];
                let displayVal = "Not answered";
                if (rawAns !== undefined && rawAns !== null && rawAns !== "") {
                  if (q.options && typeof rawAns === "string") {
                    const opt = q.options.find((o) => o.id === rawAns);
                    displayVal = opt ? opt.label : rawAns;
                  } else if (Array.isArray(rawAns)) {
                    if (q.options) {
                      displayVal = rawAns.map((id) => q.options?.find((o) => o.id === id)?.label || id).join(", ");
                    } else {
                      displayVal = rawAns.join(", ");
                    }
                  } else if (typeof rawAns === "object") {
                    displayVal = JSON.stringify(rawAns);
                  } else {
                    displayVal = String(rawAns);
                  }
                }

                return (
                  <div key={q.id} className="p-3.5 rounded-xl border border-gray-200 bg-gray-50/50 flex items-start justify-between gap-3">
                    <div className="space-y-1 text-xs flex-1">
                      <div className="font-semibold text-gray-900">
                        {idx + 1}. {q.title}
                      </div>
                      <div className="text-gray-600">
                        Answer: <span className="font-medium text-gray-900">{displayVal}</span>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setCurrentIndex(idx);
                        setIsReviewing(false);
                      }}
                      className="px-2.5 py-1 rounded-lg border border-gray-300 hover:bg-white text-indigo-600 text-xs font-semibold cursor-pointer shrink-0"
                    >
                      Edit
                    </button>
                  </div>
                );
              })}
            </div>

            <div className="pt-2 flex items-center justify-between border-t border-gray-100">
              <button
                type="button"
                onClick={() => setIsReviewing(false)}
                className="px-4 py-2 rounded-xl border border-gray-300 text-xs font-semibold text-gray-700 hover:bg-gray-50 cursor-pointer"
              >
                ← Back to Questions
              </button>
              <button
                type="button"
                disabled={isSubmitting}
                onClick={() => handleFinalSubmit(answers)}
                className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition shadow-xs cursor-pointer flex items-center gap-1.5"
              >
                <span>{isSubmitting ? "Submitting..." : "Confirm & Submit"}</span>
                <Check className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen text-gray-900 flex flex-col justify-between font-sans selection:bg-indigo-500 selection:text-white"
      style={{ backgroundColor: form.theme?.backgroundColor || "#f4f5f7" }}
    >
      {/* Top Header */}
      <header className="w-full border-b border-gray-200 bg-white sticky top-0 z-50 px-4 sm:px-8 py-3.5 flex items-center justify-between shadow-xs">
        <div className="flex items-center gap-2">
          <Link
            href="/"
            className="flex items-center transition hover:opacity-85"
            title="heyquiz"
          >
            <img src="/logo.png" alt="heyquiz" className="h-5.5 w-auto object-contain" />
          </Link>
          <span className="text-gray-300">/</span>
          <span className="text-xs font-semibold text-gray-700 truncate max-w-[200px] sm:max-w-md">
            {form.title}
          </span>
        </div>

        <div className="flex items-center gap-4">
          {secondsRemaining !== null && (
            <div
              className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-mono font-semibold border ${
                secondsRemaining < 60
                  ? "bg-rose-50 border-rose-200 text-rose-600 animate-pulse"
                  : "bg-gray-100 border-gray-200 text-gray-700"
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              <span>{formatTimer(secondsRemaining)}</span>
            </div>
          )}

          <div className="text-xs text-gray-500 font-mono font-medium">
            {currentIndex + 1} of {totalQuestions}
          </div>

          <Link
            href={`/editor/${form.id}`}
            className="hidden sm:inline-flex items-center gap-1 text-xs text-gray-500 hover:text-gray-900 transition font-medium"
          >
            <Edit3 className="w-3.5 h-3.5" />
            <span>Editor</span>
          </Link>
        </div>
      </header>

      {/* Progress & Multi-Page Step Bar */}
      {form.settings.showProgressBar !== false && form.settings.progressBarMode !== "none" && (
        <>
          {(form.settings.progressBarMode === "percentage" || !form.settings.progressBarMode) && (
            <div className="w-full h-1 bg-gray-200 sticky top-[53px] z-40">
              <motion.div
                className="h-full bg-indigo-600"
                initial={{ width: 0 }}
                animate={{ width: `${progressPercent}%` }}
                transition={{ ease: "easeOut", duration: 0.25 }}
              />
            </div>
          )}

          {(form.settings.progressBarMode === "steps" || form.settings.progressBarMode === "pages") && (
            <div className="w-full bg-white border-b border-gray-200 px-4 py-2.5 sticky top-[53px] z-40 flex items-center justify-center gap-2 overflow-x-auto shadow-xs">
              {formPages.map((page, pIdx) => {
                const isPast = pIdx < currentPageIndex;
                const isCurrent = pIdx === currentPageIndex;
                const firstQIndex = questions.findIndex((q) => (q.pageId || formPages[0].id) === page.id);
                const isClickable = Boolean(form.settings?.enablePageJumps ?? true) && firstQIndex !== -1;

                return (
                  <button
                    key={page.id}
                    type="button"
                    disabled={!isClickable}
                    onClick={() => {
                      if (isClickable && firstQIndex !== -1) {
                        setCurrentIndex(firstQIndex);
                        setRequiredError(null);
                      }
                    }}
                    className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold transition ${
                      isCurrent
                        ? "bg-indigo-600 text-white shadow-xs"
                        : isPast
                        ? "bg-indigo-50 text-indigo-700 hover:bg-indigo-100"
                        : "bg-gray-100 text-gray-500 hover:text-gray-700"
                    } ${isClickable ? "cursor-pointer" : "cursor-default"}`}
                  >
                    <span
                      className={`w-4 h-4 rounded-full text-[10px] flex items-center justify-center font-mono ${
                        isCurrent
                          ? "bg-white/20 text-white"
                          : isPast
                          ? "bg-indigo-600 text-white"
                          : "bg-gray-300 text-gray-700"
                      }`}
                    >
                      {isPast ? "✓" : pIdx + 1}
                    </span>
                    <span className="truncate max-w-[120px]">
                      {form.settings.progressBarMode === "pages"
                        ? page.title || `Page ${pIdx + 1}`
                        : `Step ${pIdx + 1}`}
                    </span>
                  </button>
                );
              })}
            </div>
          )}

          {form.settings.progressBarMode === "questions" && (
            <div className="w-full bg-white border-b border-gray-200 px-4 py-2 sticky top-[53px] z-40 flex items-center justify-center gap-1.5 overflow-x-auto">
              {questions.map((q, idx) => {
                const isCurrent = idx === currentIndex;
                const isAnswered = answers[q.id] !== undefined;
                const isClickable = Boolean(form.settings?.enablePageJumps ?? true);

                return (
                  <button
                    key={q.id}
                    type="button"
                    disabled={!isClickable}
                    onClick={() => {
                      if (isClickable) {
                        setCurrentIndex(idx);
                        setRequiredError(null);
                      }
                    }}
                    className={`w-2.5 h-2.5 rounded-full transition ${
                      isCurrent
                        ? "bg-indigo-600 ring-2 ring-indigo-300 scale-125"
                        : isAnswered
                        ? "bg-indigo-400"
                        : "bg-gray-200"
                    } ${isClickable ? "cursor-pointer hover:scale-110" : ""}`}
                    title={`Question ${idx + 1}: ${q.title}`}
                  />
                );
              })}
            </div>
          )}
        </>
      )}

      {/* Question Canvas Stage */}
      <main className="flex-1 flex items-center justify-center p-4 sm:p-8 max-w-2xl w-full mx-auto">
        <AnimatePresence mode="wait">
          {currentQ && (
            <motion.div
              key={currentQ.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="w-full bg-white rounded-2xl border border-gray-200/90 shadow-sm p-6 sm:p-8 space-y-6"
            >
              {/* Question Header */}
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-mono font-bold px-2 py-0.5 rounded bg-gray-100 text-gray-700 border border-gray-200">
                    Question {currentIndex + 1}
                  </span>
                  {(currentQ.points ?? 0) > 0 && form.mode === "quiz" && (
                    <span className="text-[11px] font-mono font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                      {currentQ.points} points
                    </span>
                  )}
                  {currentQ.required && (
                    <span className="text-xs text-rose-500">*</span>
                  )}
                </div>

                <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-gray-900 leading-snug">
                  {currentQ.title}
                </h2>

                {currentQ.description && (
                  <p className="text-gray-500 text-xs leading-relaxed">
                    {currentQ.description}
                  </p>
                )}
              </div>

              {/* Question Input Elements */}
              <div className="pt-2">
                {/* 1. Multiple Choice */}
                {currentQ.type === "multiple_choice" && (
                  <div className="space-y-2.5">
                    {currentQ.options?.map((opt, optIdx) => {
                      const isSelected = answers[currentQ.id] === opt.id;
                      return (
                        <button
                          key={opt.id}
                          onClick={() => handleSelectAnswer(currentQ.id, opt.id)}
                          className={`w-full text-left p-3.5 rounded-xl border transition flex items-center justify-between group cursor-pointer ${
                            isSelected
                              ? "bg-indigo-50 border-indigo-500 text-indigo-950 shadow-xs ring-1 ring-indigo-500"
                              : "bg-white hover:bg-gray-50 border-gray-200 text-gray-800 hover:border-gray-300"
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <span
                              className={`w-6 h-6 rounded-md flex items-center justify-center text-xs font-mono font-bold border transition ${
                                isSelected
                                  ? "bg-indigo-600 border-indigo-600 text-white"
                                  : "bg-gray-100 border-gray-200 text-gray-600 group-hover:bg-gray-200"
                              }`}
                            >
                              {optIdx + 1}
                            </span>
                            <span className="text-xs sm:text-sm font-medium">{opt.label}</span>
                          </div>
                          {isSelected && (
                            <CheckCircle2 className="w-4 h-4 text-indigo-600 shrink-0" />
                          )}
                        </button>
                      );
                    })}
                  </div>
                )}

                {/* 1b. Picture Choice (Fillout 1:1 Responsive Visual Grid) */}
                {currentQ.type === "picture_choice" && (
                  <div
                    className={`grid gap-4 ${
                      (currentQ.pictureColumns || 3) === 2
                        ? "grid-cols-1 sm:grid-cols-2"
                        : (currentQ.pictureColumns || 3) === 4
                        ? "grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4"
                        : "grid-cols-1 sm:grid-cols-2 md:grid-cols-3"
                    }`}
                  >
                    {currentQ.options?.map((opt, optIdx) => {
                      const isSelected = answers[currentQ.id] === opt.id;
                      const letter = String.fromCharCode(65 + optIdx); // A, B, C...
                      const aspectClass =
                        currentQ.pictureAspectRatio === "square"
                          ? "aspect-square"
                          : currentQ.pictureAspectRatio === "portrait"
                          ? "aspect-[3/4]"
                          : "aspect-video";

                      return (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() => handleSelectAnswer(currentQ.id, opt.id)}
                          className={`group relative flex flex-col rounded-2xl border text-left overflow-hidden transition-all duration-200 cursor-pointer ${
                            isSelected
                              ? "border-indigo-600 ring-2 ring-indigo-500 shadow-md bg-indigo-50/20"
                              : "border-gray-200 bg-white hover:border-gray-300 hover:shadow-md"
                          }`}
                        >
                          {/* Image Box */}
                          <div className={`w-full relative overflow-hidden bg-gray-100 ${aspectClass}`}>
                            {opt.imageUrl ? (
                              <img
                                src={opt.imageUrl}
                                alt={opt.label}
                                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                              />
                            ) : (
                              <div className="w-full h-full flex flex-col items-center justify-center text-gray-400 gap-1.5 p-4 text-center">
                                <ImageIcon className="w-8 h-8 stroke-[1.5]" />
                                <span className="text-xs">No image provided</span>
                              </div>
                            )}

                            {/* Floating Top-Left Letter Badge (A, B, C...) */}
                            <div className="absolute top-2.5 left-2.5 z-10">
                              <span
                                className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold font-mono shadow-sm transition backdrop-blur-md ${
                                  isSelected
                                    ? "bg-indigo-600 text-white"
                                    : "bg-white/90 text-gray-700 border border-black/10 group-hover:bg-white"
                                }`}
                              >
                                {letter}
                              </span>
                            </div>

                            {/* Floating Top-Right Selection Indicator Badge */}
                            <div className="absolute top-2.5 right-2.5 z-10">
                              <span
                                className={`w-6 h-6 rounded-full flex items-center justify-center transition border shadow-xs ${
                                  isSelected
                                    ? "bg-indigo-600 border-indigo-600 text-white ring-2 ring-white/80"
                                    : "bg-white/80 border-gray-300 text-transparent group-hover:border-gray-400 group-hover:bg-white"
                                }`}
                              >
                                <Check className="w-3.5 h-3.5 stroke-[3]" />
                              </span>
                            </div>
                          </div>

                          {/* Card Label Bar */}
                          <div className="p-3.5 bg-white flex-1 flex flex-col justify-center border-t border-gray-100">
                            <div className="flex items-center justify-between gap-2">
                              <span
                                className={`text-sm font-semibold transition truncate ${
                                  isSelected ? "text-indigo-900" : "text-gray-800 group-hover:text-indigo-600"
                                }`}
                              >
                                {opt.label}
                              </span>
                            </div>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                )}

                {/* 1c. Image Multi-Select (Fillout Parity Grid) */}
                {currentQ.type === "image_multiselect" && (
                  <div
                    className={`grid gap-4 ${
                      (currentQ.pictureColumns || 3) === 2
                        ? "grid-cols-1 sm:grid-cols-2"
                        : (currentQ.pictureColumns || 3) === 4
                        ? "grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4"
                        : "grid-cols-1 sm:grid-cols-2 md:grid-cols-3"
                    }`}
                  >
                    {currentQ.options?.map((opt, optIdx) => {
                      const selectedList: string[] = Array.isArray(answers[currentQ.id]) ? answers[currentQ.id] : [];
                      const isSelected = selectedList.includes(opt.id);
                      const letter = String.fromCharCode(65 + optIdx);
                      const aspectClass =
                        currentQ.pictureAspectRatio === "square"
                          ? "aspect-square"
                          : currentQ.pictureAspectRatio === "portrait"
                          ? "aspect-[3/4]"
                          : "aspect-video";

                      return (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() => handleMultiSelectToggle(currentQ.id, opt.id)}
                          className={`group relative flex flex-col rounded-2xl border text-left overflow-hidden transition-all duration-200 cursor-pointer ${
                            isSelected
                              ? "border-indigo-600 ring-2 ring-indigo-500 shadow-md bg-indigo-50/20"
                              : "border-gray-200 bg-white hover:border-gray-300 hover:shadow-md"
                          }`}
                        >
                          <div className={`w-full relative overflow-hidden bg-gray-100 ${aspectClass}`}>
                            {opt.imageUrl ? (
                              <img
                                src={opt.imageUrl}
                                alt={opt.label}
                                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                              />
                            ) : (
                              <div className="w-full h-full flex flex-col items-center justify-center text-gray-400 gap-1.5 p-4 text-center">
                                <ImageIcon className="w-8 h-8 stroke-[1.5]" />
                                <span className="text-xs">No image provided</span>
                              </div>
                            )}

                            <div className="absolute top-2.5 left-2.5 z-10">
                              <span
                                className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold font-mono shadow-sm transition backdrop-blur-md ${
                                  isSelected
                                    ? "bg-indigo-600 text-white"
                                    : "bg-white/90 text-gray-700 border border-black/10 group-hover:bg-white"
                                }`}
                              >
                                {letter}
                              </span>
                            </div>

                            <div className="absolute top-2.5 right-2.5 z-10">
                              <span
                                className={`w-6 h-6 rounded-md flex items-center justify-center transition border shadow-xs ${
                                  isSelected
                                    ? "bg-indigo-600 border-indigo-600 text-white ring-2 ring-white/80"
                                    : "bg-white/80 border-gray-300 text-transparent group-hover:border-gray-400 group-hover:bg-white"
                                }`}
                              >
                                <Check className="w-3.5 h-3.5 stroke-[3]" />
                              </span>
                            </div>
                          </div>

                          <div className="p-3.5 bg-white flex-1 flex flex-col justify-center border-t border-gray-100">
                            <span
                              className={`text-sm font-semibold transition truncate ${
                                isSelected ? "text-indigo-900 font-bold" : "text-gray-800 group-hover:text-indigo-600"
                              }`}
                            >
                              {opt.label}
                            </span>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                )}

                {/* 2. Segmented Control */}
                {currentQ.type === "segmented" && (
                  <div className="pt-1">
                    <div className="flex p-1 bg-gray-100 rounded-xl border border-gray-200 gap-1 w-full overflow-x-auto">
                      {currentQ.options?.map((opt) => {
                        const isSelected = answers[currentQ.id] === opt.id;
                        return (
                          <button
                            key={opt.id}
                            type="button"
                            onClick={() => handleSelectAnswer(currentQ.id, opt.id)}
                            className={`flex-1 py-2.5 px-3 text-xs sm:text-sm font-medium rounded-lg transition text-center cursor-pointer ${
                              isSelected
                                ? "bg-white text-indigo-600 shadow-xs font-bold ring-1 ring-indigo-500/20"
                                : "text-gray-600 hover:text-gray-900 hover:bg-gray-200/50"
                            }`}
                          >
                            {opt.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* 3. Switch (True / False) */}
                {currentQ.type === "switch" && (
                  <div className="grid grid-cols-2 gap-4">
                    {currentQ.options?.map((opt) => {
                      const isSelected = answers[currentQ.id] === opt.id;
                      return (
                        <button
                          key={opt.id}
                          onClick={() => handleSelectAnswer(currentQ.id, opt.id)}
                          className={`p-5 rounded-xl border text-center transition font-semibold text-base flex flex-col items-center justify-center gap-2 cursor-pointer ${
                            isSelected
                              ? "bg-indigo-50 border-indigo-500 text-indigo-950 shadow-xs ring-1 ring-indigo-500"
                              : "bg-white hover:bg-gray-50 border-gray-200 text-gray-800 hover:border-gray-300"
                          }`}
                        >
                          <span>{opt.label}</span>
                        </button>
                      );
                    })}
                  </div>
                )}

                {/* 4. Single Checkbox */}
                {currentQ.type === "checkbox" && (
                  <div>
                    <button
                      type="button"
                      onClick={() => {
                        setRequiredError(null);
                        setAnswers({ ...answers, [currentQ.id]: !answers[currentQ.id] });
                      }}
                      className={`w-full text-left p-4 rounded-xl border transition flex items-center gap-3 cursor-pointer ${
                        answers[currentQ.id]
                          ? "bg-indigo-50 border-indigo-500 text-indigo-950 shadow-xs"
                          : "bg-white hover:bg-gray-50 border-gray-200 text-gray-800"
                      }`}
                    >
                      <div
                        className={`w-5 h-5 rounded border flex items-center justify-center transition shrink-0 ${
                          answers[currentQ.id]
                            ? "bg-indigo-600 border-indigo-600 text-white"
                            : "border-gray-300 bg-white"
                        }`}
                      >
                        {answers[currentQ.id] && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                      </div>
                      <span className="text-xs sm:text-sm font-medium">
                        {currentQ.placeholder || "I confirm and acknowledge"}
                      </span>
                    </button>
                  </div>
                )}

                {/* 5. Terms & Conditions */}
                {currentQ.type === "terms" && (
                  <div>
                    <button
                      type="button"
                      onClick={() => {
                        setRequiredError(null);
                        setAnswers({ ...answers, [currentQ.id]: !answers[currentQ.id] });
                      }}
                      className={`w-full text-left p-4 rounded-xl border transition flex items-start gap-3 cursor-pointer ${
                        answers[currentQ.id]
                          ? "bg-indigo-50 border-indigo-500 text-indigo-950 shadow-xs"
                          : "bg-white hover:bg-gray-50 border-gray-200 text-gray-800"
                      }`}
                    >
                      <div
                        className={`w-5 h-5 rounded border flex items-center justify-center transition shrink-0 mt-0.5 ${
                          answers[currentQ.id]
                            ? "bg-indigo-600 border-indigo-600 text-white"
                            : "border-gray-300 bg-white"
                        }`}
                      >
                        {answers[currentQ.id] && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                      </div>
                      <div className="text-xs sm:text-sm">
                        <span>{currentQ.termsText || "I agree to the Terms of Service and Privacy Policy"}</span>
                        <a
                          href={currentQ.termsUrl || "#"}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => e.stopPropagation()}
                          className="text-indigo-600 underline font-semibold inline-flex items-center gap-1 ml-1 hover:text-indigo-800"
                        >
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      </div>
                    </button>
                  </div>
                )}

                {/* 6. Multiselect / Checkboxes */}
                {(currentQ.type === "multiselect" || currentQ.type === "checkboxes") && (
                  <div className="space-y-2.5">
                    {currentQ.options?.map((opt) => {
                      const selectedList: string[] = answers[currentQ.id] || [];
                      const isSelected = selectedList.includes(opt.id);
                      return (
                        <button
                          key={opt.id}
                          onClick={() => handleMultiSelectToggle(currentQ.id, opt.id)}
                          className={`w-full text-left p-3.5 rounded-xl border transition flex items-center justify-between cursor-pointer ${
                            isSelected
                              ? "bg-indigo-50 border-indigo-500 text-indigo-950 shadow-xs"
                              : "bg-white hover:bg-gray-50 border-gray-200 text-gray-800 hover:border-gray-300"
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <div
                              className={`w-4 h-4 rounded border flex items-center justify-center transition ${
                                isSelected
                                  ? "bg-indigo-600 border-indigo-600 text-white"
                                  : "border-gray-300 bg-white"
                              }`}
                            >
                              {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                            </div>
                            <span className="text-xs sm:text-sm font-medium">{opt.label}</span>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                )}

                {/* 7. Choice Matrix / Likert Table Grid */}
                {currentQ.type === "choice_matrix" && (
                  <div className="border border-gray-200 rounded-xl overflow-hidden bg-white shadow-xs">
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs sm:text-sm">
                        <thead className="bg-gray-50 border-b border-gray-200 text-gray-600">
                          <tr>
                            <th className="p-3 font-semibold">Evaluation Criteria</th>
                            {(currentQ.columns || ["Poor", "Fair", "Good", "Excellent"]).map((col, cIdx) => (
                              <th key={cIdx} className="p-3 text-center font-semibold">
                                {col}
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100">
                          {(currentQ.rows || ["Ease of use", "Speed & Performance", "Customer Support"]).map((row, rIdx) => {
                            const matrixAnswers = answers[currentQ.id] || {};
                            const selectedCol = matrixAnswers[row];
                            return (
                              <tr key={rIdx} className="hover:bg-gray-50/70 transition">
                                <td className="p-3 font-medium text-gray-800">{row}</td>
                                {(currentQ.columns || ["Poor", "Fair", "Good", "Excellent"]).map((col, cIdx) => (
                                  <td key={cIdx} className="p-3 text-center">
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setRequiredError(null);
                                        setAnswers({
                                          ...answers,
                                          [currentQ.id]: {
                                            ...matrixAnswers,
                                            [row]: col,
                                          },
                                        });
                                      }}
                                      className={`w-5 h-5 rounded-full border mx-auto flex items-center justify-center transition cursor-pointer ${
                                        selectedCol === col
                                          ? "border-indigo-600 bg-indigo-600 ring-2 ring-indigo-200"
                                          : "border-gray-300 hover:border-gray-400 bg-white"
                                      }`}
                                    >
                                      {selectedCol === col && <div className="w-2 h-2 rounded-full bg-white" />}
                                    </button>
                                  </td>
                                ))}
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* 7b. Matrix Multi-Select (Fillout Parity Grid) */}
                {currentQ.type === "matrix_multiselect" && (
                  <div className="border border-gray-200 rounded-xl overflow-hidden bg-white shadow-xs">
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs sm:text-sm">
                        <thead className="bg-gray-50 border-b border-gray-200 text-gray-600">
                          <tr>
                            <th className="p-3 font-semibold">Evaluation Criteria</th>
                            {(currentQ.columns || ["Basic", "Standard", "Pro"]).map((col, cIdx) => (
                              <th key={cIdx} className="p-3 text-center font-semibold">
                                {col}
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100">
                          {(currentQ.rows || ["Feature A", "Feature B", "Feature C"]).map((row, rIdx) => {
                            const matrixAnswers = answers[currentQ.id] || {};
                            const selectedCols: string[] = Array.isArray(matrixAnswers[row]) ? matrixAnswers[row] : [];
                            return (
                              <tr key={rIdx} className="hover:bg-gray-50/70 transition">
                                <td className="p-3 font-medium text-gray-800">{row}</td>
                                {(currentQ.columns || ["Basic", "Standard", "Pro"]).map((col, cIdx) => {
                                  const isChecked = selectedCols.includes(col);
                                  return (
                                    <td key={cIdx} className="p-3 text-center">
                                      <button
                                        type="button"
                                        onClick={() => {
                                          setRequiredError(null);
                                          const nextCols = isChecked
                                            ? selectedCols.filter((c) => c !== col)
                                            : [...selectedCols, col];
                                          setAnswers({
                                            ...answers,
                                            [currentQ.id]: {
                                              ...matrixAnswers,
                                              [row]: nextCols,
                                            },
                                          });
                                        }}
                                        className={`w-5 h-5 rounded-md border mx-auto flex items-center justify-center transition cursor-pointer ${
                                          isChecked
                                            ? "border-indigo-600 bg-indigo-600 text-white"
                                            : "border-gray-300 hover:border-gray-400 bg-white"
                                        }`}
                                      >
                                        {isChecked && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                                      </button>
                                    </td>
                                  );
                                })}
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* 8. Ranking Order */}
                {currentQ.type === "ranking" && (
                  <div className="space-y-2">
                    <p className="text-xs text-gray-500 mb-2">Use the arrows to rank items from highest to lowest:</p>
                    {(() => {
                      const currentRanked: string[] = answers[currentQ.id] || (currentQ.items || ["First Priority", "Second Priority", "Third Priority"]);
                      return currentRanked.map((item, idx) => (
                        <div
                          key={item}
                          className="flex items-center justify-between p-3 rounded-xl border border-gray-200 bg-white hover:border-gray-300 transition shadow-xs"
                        >
                          <div className="flex items-center gap-3">
                            <span className="w-6 h-6 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-bold font-mono flex items-center justify-center">
                              {idx + 1}
                            </span>
                            <span className="text-xs sm:text-sm font-semibold text-gray-800">{item}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <button
                              type="button"
                              disabled={idx === 0}
                              onClick={() => {
                                setRequiredError(null);
                                const nextList = [...currentRanked];
                                const [moved] = nextList.splice(idx, 1);
                                nextList.splice(idx - 1, 0, moved);
                                setAnswers({ ...answers, [currentQ.id]: nextList });
                              }}
                              className="p-1 rounded text-gray-400 hover:text-gray-700 disabled:opacity-20 hover:bg-gray-100"
                              title="Move higher"
                            >
                              <ChevronUp className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              disabled={idx === currentRanked.length - 1}
                              onClick={() => {
                                setRequiredError(null);
                                const nextList = [...currentRanked];
                                const [moved] = nextList.splice(idx, 1);
                                nextList.splice(idx + 1, 0, moved);
                                setAnswers({ ...answers, [currentQ.id]: nextList });
                              }}
                              className="p-1 rounded text-gray-400 hover:text-gray-700 disabled:opacity-20 hover:bg-gray-100"
                              title="Move lower"
                            >
                              <ChevronDown className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ));
                    })()}
                  </div>
                )}

                {/* 9. Full Name */}
                {currentQ.type === "full_name" && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-gray-600">First Name</label>
                      <input
                        type="text"
                        autoFocus
                        placeholder="First name"
                        value={answers[currentQ.id]?.firstName ?? ""}
                        onChange={(e) => {
                          setRequiredError(null);
                          setAnswers({
                            ...answers,
                            [currentQ.id]: {
                              ...(answers[currentQ.id] || {}),
                              firstName: e.target.value,
                            },
                          });
                        }}
                        className="w-full bg-white border border-gray-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 rounded-xl px-4 py-3 text-gray-900 text-sm outline-none transition"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-gray-600">Last Name</label>
                      <input
                        type="text"
                        placeholder="Last name"
                        value={answers[currentQ.id]?.lastName ?? ""}
                        onChange={(e) => {
                          setRequiredError(null);
                          setAnswers({
                            ...answers,
                            [currentQ.id]: {
                              ...(answers[currentQ.id] || {}),
                              lastName: e.target.value,
                            },
                          });
                        }}
                        className="w-full bg-white border border-gray-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 rounded-xl px-4 py-3 text-gray-900 text-sm outline-none transition"
                      />
                    </div>
                  </div>
                )}

                {/* 10. Address */}
                {currentQ.type === "address" && (
                  <div className="space-y-3">
                    <input
                      type="text"
                      placeholder="Street address"
                      value={answers[currentQ.id]?.street ?? ""}
                      onChange={(e) => {
                        setRequiredError(null);
                        setAnswers({
                          ...answers,
                          [currentQ.id]: { ...(answers[currentQ.id] || {}), street: e.target.value },
                        });
                      }}
                      className="w-full bg-white border border-gray-300 focus:border-indigo-500 rounded-xl px-4 py-3 text-gray-900 text-sm outline-none"
                    />
                    <div className="grid grid-cols-3 gap-2">
                      <input
                        type="text"
                        placeholder="City"
                        value={answers[currentQ.id]?.city ?? ""}
                        onChange={(e) => {
                          setRequiredError(null);
                          setAnswers({
                            ...answers,
                            [currentQ.id]: { ...(answers[currentQ.id] || {}), city: e.target.value },
                          });
                        }}
                        className="w-full bg-white border border-gray-300 focus:border-indigo-500 rounded-xl px-3 py-2.5 text-gray-900 text-xs sm:text-sm outline-none"
                      />
                      <input
                        type="text"
                        placeholder="State"
                        value={answers[currentQ.id]?.state ?? ""}
                        onChange={(e) => {
                          setRequiredError(null);
                          setAnswers({
                            ...answers,
                            [currentQ.id]: { ...(answers[currentQ.id] || {}), state: e.target.value },
                          });
                        }}
                        className="w-full bg-white border border-gray-300 focus:border-indigo-500 rounded-xl px-3 py-2.5 text-gray-900 text-xs sm:text-sm outline-none"
                      />
                      <input
                        type="text"
                        placeholder="ZIP"
                        value={answers[currentQ.id]?.zip ?? ""}
                        onChange={(e) => {
                          setRequiredError(null);
                          setAnswers({
                            ...answers,
                            [currentQ.id]: { ...(answers[currentQ.id] || {}), zip: e.target.value },
                          });
                        }}
                        className="w-full bg-white border border-gray-300 focus:border-indigo-500 rounded-xl px-3 py-2.5 text-gray-900 text-xs sm:text-sm outline-none"
                      />
                    </div>
                  </div>
                )}

                {/* 11. Website URL */}
                {currentQ.type === "website" && (
                  <div className="relative">
                    <Globe className="w-4 h-4 text-gray-400 absolute left-4 top-3.5" />
                    <input
                      type="url"
                      autoFocus
                      placeholder="https://example.com"
                      value={answers[currentQ.id] ?? ""}
                      onChange={(e) => {
                        setRequiredError(null);
                        setAnswers({ ...answers, [currentQ.id]: e.target.value });
                      }}
                      className="w-full bg-white border border-gray-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 rounded-xl pl-11 pr-4 py-3 text-gray-900 text-sm outline-none transition font-mono"
                    />
                  </div>
                )}

                {/* 12. Currency */}
                {currentQ.type === "currency" && (
                  <div className="relative">
                    <span className="font-bold text-gray-500 text-base absolute left-4 top-3">
                      {currentQ.currencySymbol || "$"}
                    </span>
                    <input
                      type="number"
                      step="0.01"
                      autoFocus
                      placeholder="0.00"
                      value={answers[currentQ.id] ?? ""}
                      onChange={(e) => {
                        setRequiredError(null);
                        setAnswers({ ...answers, [currentQ.id]: e.target.value });
                      }}
                      className="w-full bg-white border border-gray-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 rounded-xl pl-10 pr-4 py-3 text-gray-900 text-sm outline-none transition font-mono"
                    />
                  </div>
                )}

                {/* 13. Password */}
                {currentQ.type === "password" && (
                  <div className="relative">
                    <Lock className="w-4 h-4 text-gray-400 absolute left-4 top-3.5" />
                    <input
                      type={showPassword ? "text" : "password"}
                      autoFocus
                      placeholder="Enter password..."
                      value={answers[currentQ.id] ?? ""}
                      onChange={(e) => {
                        setRequiredError(null);
                        setAnswers({ ...answers, [currentQ.id]: e.target.value });
                      }}
                      className="w-full bg-white border border-gray-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 rounded-xl pl-11 pr-11 py-3 text-gray-900 text-sm outline-none transition"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3.5 top-3.5 text-gray-400 hover:text-gray-600"
                      title={showPassword ? "Hide password" : "Show password"}
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                )}

                {/* 14. Short Answer / Email / Phone / Number */}
                {(currentQ.type === "short_answer" || currentQ.type === "email" || currentQ.type === "phone" || currentQ.type === "number") && (
                  <div>
                    <input
                      type={currentQ.type === "email" ? "email" : currentQ.type === "number" ? "number" : "text"}
                      autoFocus
                      placeholder={currentQ.placeholder || "Type your answer here..."}
                      value={answers[currentQ.id] ?? ""}
                      onChange={(e) => {
                        setRequiredError(null);
                        setAnswers({ ...answers, [currentQ.id]: e.target.value });
                      }}
                      className="w-full bg-white border border-gray-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 rounded-xl px-4 py-3 text-gray-900 text-sm outline-none transition"
                    />
                  </div>
                )}

                {/* 15. Paragraph / Long Text */}
                {currentQ.type === "paragraph" && (
                  <div>
                    <textarea
                      rows={4}
                      autoFocus
                      placeholder={currentQ.placeholder || "Write your detailed response..."}
                      value={answers[currentQ.id] ?? ""}
                      onChange={(e) => {
                        setRequiredError(null);
                        setAnswers({ ...answers, [currentQ.id]: e.target.value });
                      }}
                      className="w-full bg-white border border-gray-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 rounded-xl px-4 py-3 text-gray-900 text-sm outline-none transition resize-none"
                    />
                  </div>
                )}

                {/* 16. Rating / Opinion Scale / NPS */}
                {(currentQ.type === "opinion_scale" || currentQ.type === "rating" || currentQ.type === "nps") && (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between gap-1.5 overflow-x-auto py-1">
                      {Array.from(
                        { length: (currentQ.maxRating ?? 5) - (currentQ.minRating ?? 1) + 1 },
                        (_, i) => (currentQ.minRating ?? 1) + i
                      ).map((val) => {
                        const isSelected = answers[currentQ.id] === val;
                        return (
                          <button
                            key={val}
                            onClick={() => handleSelectAnswer(currentQ.id, val)}
                            className={`flex-1 min-w-[42px] h-11 rounded-xl border text-xs font-bold font-mono transition flex items-center justify-center cursor-pointer ${
                              isSelected
                                ? "bg-indigo-600 border-indigo-600 text-white shadow-xs scale-105"
                                : "bg-white hover:bg-gray-50 border-gray-200 text-gray-700 hover:border-gray-300"
                            }`}
                          >
                            {val}
                          </button>
                        );
                      })}
                    </div>
                    {currentQ.ratingLabels && (
                      <div className="flex items-center justify-between text-[11px] text-gray-500 font-medium px-1">
                        <span>{currentQ.ratingLabels.low || "Low"}</span>
                        <span>{currentQ.ratingLabels.high || "High"}</span>
                      </div>
                    )}
                  </div>
                )}

                {/* 17. Emoji Sentiment Rating */}
                {currentQ.type === "emoji_rating" && (
                  <div className="flex items-center justify-between gap-2">
                    {[
                      { val: 1, emoji: "😠", label: "Very Bad" },
                      { val: 2, emoji: "🙁", label: "Bad" },
                      { val: 3, emoji: "😐", label: "Neutral" },
                      { val: 4, emoji: "🙂", label: "Good" },
                      { val: 5, emoji: "😀", label: "Great" },
                    ].map((item) => {
                      const isSelected = answers[currentQ.id] === item.val;
                      return (
                        <button
                          key={item.val}
                          type="button"
                          onClick={() => handleSelectAnswer(currentQ.id, item.val)}
                          className={`flex-1 py-4 rounded-2xl border text-center transition flex flex-col items-center gap-1 cursor-pointer ${
                            isSelected
                              ? "bg-indigo-50 border-indigo-500 shadow-xs ring-2 ring-indigo-500/20 scale-105"
                              : "bg-white hover:bg-gray-50 border-gray-200"
                          }`}
                        >
                          <span className="text-2xl sm:text-3xl">{item.emoji}</span>
                          <span className="text-[10px] font-semibold text-gray-500">{item.label}</span>
                        </button>
                      );
                    })}
                  </div>
                )}

                {/* 18. Thumbs Up / Down */}
                {currentQ.type === "thumbs" && (
                  <div className="grid grid-cols-2 gap-4">
                    <button
                      type="button"
                      onClick={() => handleSelectAnswer(currentQ.id, "up")}
                      className={`p-5 rounded-2xl border text-center transition flex items-center justify-center gap-2.5 font-semibold text-sm cursor-pointer ${
                        answers[currentQ.id] === "up"
                          ? "bg-emerald-50 border-emerald-500 text-emerald-800 ring-2 ring-emerald-500/20 shadow-xs"
                          : "bg-white hover:bg-gray-50 border-gray-200 text-gray-700"
                      }`}
                    >
                      <ThumbsUp className="w-5 h-5 text-emerald-600" />
                      <span>Thumbs Up</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleSelectAnswer(currentQ.id, "down")}
                      className={`p-5 rounded-2xl border text-center transition flex items-center justify-center gap-2.5 font-semibold text-sm cursor-pointer ${
                        answers[currentQ.id] === "down"
                          ? "bg-rose-50 border-rose-500 text-rose-800 ring-2 ring-rose-500/20 shadow-xs"
                          : "bg-white hover:bg-gray-50 border-gray-200 text-gray-700"
                      }`}
                    >
                      <ThumbsDown className="w-5 h-5 text-rose-600" />
                      <span>Thumbs Down</span>
                    </button>
                  </div>
                )}

                {/* 19. Dropdown */}
                {currentQ.type === "dropdown" && (
                  <div>
                    <select
                      value={answers[currentQ.id] ?? ""}
                      onChange={(e) => handleSelectAnswer(currentQ.id, e.target.value)}
                      className="w-full bg-white border border-gray-300 focus:border-indigo-500 rounded-xl px-4 py-3 text-gray-900 text-xs sm:text-sm outline-none transition"
                    >
                      <option value="">Select an option...</option>
                      {currentQ.options?.map((opt) => (
                        <option key={opt.id} value={opt.id}>
                          {opt.label}
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                {/* 20. Date Picker */}
                {currentQ.type === "date" && (
                  <div>
                    <input
                      type="date"
                      value={answers[currentQ.id] ?? ""}
                      onChange={(e) => {
                        setRequiredError(null);
                        setAnswers({ ...answers, [currentQ.id]: e.target.value });
                      }}
                      className="w-full bg-white border border-gray-300 focus:border-indigo-500 rounded-xl px-4 py-3 text-gray-900 text-xs sm:text-sm outline-none transition"
                    />
                  </div>
                )}

                {/* 21. Time Picker */}
                {currentQ.type === "time" && (
                  <div>
                    <input
                      type="time"
                      value={answers[currentQ.id] ?? ""}
                      onChange={(e) => {
                        setRequiredError(null);
                        setAnswers({ ...answers, [currentQ.id]: e.target.value });
                      }}
                      className="w-full bg-white border border-gray-300 focus:border-indigo-500 rounded-xl px-4 py-3 text-gray-900 text-xs sm:text-sm outline-none transition font-mono"
                    />
                  </div>
                )}

                {/* 22. Color Picker */}
                {currentQ.type === "color_picker" && (
                  <div className="flex items-center gap-3 p-3 bg-white border border-gray-300 rounded-xl">
                    <input
                      type="color"
                      value={answers[currentQ.id] ?? "#4F46E5"}
                      onChange={(e) => {
                        setRequiredError(null);
                        setAnswers({ ...answers, [currentQ.id]: e.target.value });
                      }}
                      className="w-10 h-10 rounded-lg cursor-pointer border-0 p-0"
                    />
                    <span className="font-mono text-xs font-semibold text-gray-700">
                      {answers[currentQ.id] ?? "#4F46E5"}
                    </span>
                  </div>
                )}

                {/* 23. Slider */}
                {currentQ.type === "slider" && (
                  <div className="space-y-3 pt-2">
                    <input
                      type="range"
                      min={currentQ.minVal ?? 0}
                      max={currentQ.maxVal ?? 100}
                      step={currentQ.stepVal ?? 1}
                      value={answers[currentQ.id] ?? (currentQ.minVal ?? 0)}
                      onChange={(e) => {
                        setRequiredError(null);
                        setAnswers({ ...answers, [currentQ.id]: Number(e.target.value) });
                      }}
                      className="w-full accent-indigo-600 cursor-pointer h-2 bg-gray-200 rounded-lg"
                    />
                    <div className="flex items-center justify-between text-xs font-mono text-gray-500">
                      <span>{currentQ.minVal ?? 0}</span>
                      <span className="font-bold text-sm text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-lg border border-indigo-200">
                        {answers[currentQ.id] ?? (currentQ.minVal ?? 0)}
                      </span>
                      <span>{currentQ.maxVal ?? 100}</span>
                    </div>
                  </div>
                )}

                {/* 24. File Upload */}
                {currentQ.type === "file_upload" && (
                  <div className="border-2 border-dashed border-gray-300 hover:border-indigo-400 rounded-2xl p-8 text-center bg-gray-50/50 transition">
                    <UploadCloud className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                    <label className="cursor-pointer">
                      <span className="text-xs font-semibold text-indigo-600 hover:text-indigo-700 underline">
                        Click to browse file
                      </span>
                      <input
                        type="file"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            setRequiredError(null);
                            setAnswers({ ...answers, [currentQ.id]: file.name });
                          }
                        }}
                      />
                    </label>
                    <p className="text-[11px] text-gray-400 mt-1">Supports common documents and images</p>
                    {answers[currentQ.id] && (
                      <div className="mt-3 inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-lg text-xs font-medium">
                        <Check className="w-3.5 h-3.5" />
                        <span>Attached: {answers[currentQ.id]}</span>
                      </div>
                    )}
                  </div>
                )}

                {/* 25. Signature */}
                {currentQ.type === "signature" && (
                  <div className="space-y-2">
                    <div className="border border-gray-300 rounded-xl p-4 bg-gray-50/60 focus-within:border-indigo-500 focus-within:bg-white transition">
                      <input
                        type="text"
                        placeholder="Type full legal name to sign..."
                        value={answers[currentQ.id] ?? ""}
                        onChange={(e) => {
                          setRequiredError(null);
                          setAnswers({ ...answers, [currentQ.id]: e.target.value });
                        }}
                        className="w-full bg-transparent text-base font-serif italic text-gray-900 outline-none placeholder:text-gray-400"
                      />
                    </div>
                    <span className="text-[10px] text-gray-400 font-mono">Digitally signed verification</span>
                  </div>
                )}

                {/* 26. Subheading Display */}
                {currentQ.type === "subheading" && (
                  <div className="p-4 rounded-xl bg-gray-50 border border-gray-200 text-gray-700 text-xs sm:text-sm leading-relaxed">
                    {currentQ.subheadingText || "Subheading details and contextual guidance."}
                  </div>
                )}

                {/* 27. Divider Display */}
                {currentQ.type === "divider" && (
                  <div className="py-3">
                    <hr className="border-gray-200" />
                  </div>
                )}

                {/* 28. Heading / Banner Display Text */}
                {(currentQ.type === "heading" || currentQ.type === "banner") && (
                  <div className="p-4 rounded-xl bg-indigo-50/60 border border-indigo-200/80 text-indigo-900 space-y-1">
                    <div className="flex items-center gap-2 font-bold text-xs">
                      <Sparkles className="w-4 h-4 text-indigo-600" />
                      <span>Notice &amp; Instructions</span>
                    </div>
                    <p className="text-xs text-indigo-700 leading-relaxed">
                      Press Continue when you have finished reading this section.
                    </p>
                  </div>
                )}

                {/* 29. Like / Dislike (Ratings & Feedback) */}
                {currentQ.type === "like_dislike" && (
                  <div className="grid grid-cols-2 gap-4">
                    <button
                      type="button"
                      onClick={() => handleSelectAnswer(currentQ.id, "like")}
                      className={`p-6 rounded-2xl border text-center transition flex flex-col items-center justify-center gap-2 cursor-pointer ${
                        answers[currentQ.id] === "like"
                          ? "bg-rose-50 border-rose-500 text-rose-700 ring-2 ring-rose-500/20 shadow-xs"
                          : "bg-white hover:bg-gray-50 border-gray-200 text-gray-700"
                      }`}
                    >
                      <Heart className={`w-8 h-8 ${answers[currentQ.id] === "like" ? "fill-rose-500 text-rose-500" : "text-rose-400"}`} />
                      <span className="text-sm font-bold">Like</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleSelectAnswer(currentQ.id, "dislike")}
                      className={`p-6 rounded-2xl border text-center transition flex flex-col items-center justify-center gap-2 cursor-pointer ${
                        answers[currentQ.id] === "dislike"
                          ? "bg-gray-100 border-gray-500 text-gray-800 ring-2 ring-gray-400/20 shadow-xs"
                          : "bg-white hover:bg-gray-50 border-gray-200 text-gray-700"
                      }`}
                    >
                      <HeartCrack className={`w-8 h-8 ${answers[currentQ.id] === "dislike" ? "fill-gray-600 text-gray-600" : "text-gray-400"}`} />
                      <span className="text-sm font-bold">Dislike</span>
                    </button>
                  </div>
                )}

                {/* 30. Audio Voice Recorder (Ratings & Feedback) */}
                {currentQ.type === "audio_recorder" && (
                  <div className="p-6 rounded-2xl border border-gray-200 bg-gray-50/60 text-center space-y-4">
                    <div className="w-14 h-14 rounded-full bg-white border border-gray-200 shadow-xs flex items-center justify-center mx-auto text-indigo-600">
                      <Mic className={`w-7 h-7 ${isRecordingAudio ? "text-rose-600 animate-pulse" : "text-indigo-600"}`} />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-gray-900">
                        {isRecordingAudio ? "Recording voice note..." : answers[currentQ.id] ? "Voice note captured" : "Record your voice response"}
                      </div>
                      <div className="text-[11px] font-mono text-gray-500 mt-1">
                        {isRecordingAudio ? `00:${recordingSeconds < 10 ? "0" : ""}${recordingSeconds}` : answers[currentQ.id] ? "Duration: 00:12 • Ready for submission" : "Click button below to start"}
                      </div>
                    </div>
                    <div className="flex items-center justify-center gap-3">
                      {!isRecordingAudio && !answers[currentQ.id] && (
                        <button
                          type="button"
                          onClick={() => {
                            setIsRecordingAudio(true);
                            setRecordingSeconds(0);
                            setRequiredError(null);
                          }}
                          className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs transition shadow-xs flex items-center gap-1.5 cursor-pointer"
                        >
                          <Mic className="w-3.5 h-3.5" />
                          <span>Start Recording</span>
                        </button>
                      )}
                      {isRecordingAudio && (
                        <button
                          type="button"
                          onClick={() => {
                            setIsRecordingAudio(false);
                            setAnswers({ ...answers, [currentQ.id]: `recording_${Date.now()}.mp3` });
                          }}
                          className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-semibold text-xs transition shadow-xs flex items-center gap-1.5 cursor-pointer animate-pulse"
                        >
                          <Square className="w-3.5 h-3.5 fill-white" />
                          <span>Stop Recording</span>
                        </button>
                      )}
                      {answers[currentQ.id] && !isRecordingAudio && (
                        <div className="flex items-center gap-2">
                          <div className="px-3.5 py-1.5 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs font-medium flex items-center gap-1.5">
                            <Volume2 className="w-3.5 h-3.5" />
                            <span>Audio Attached</span>
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              setAnswers({ ...answers, [currentQ.id]: undefined });
                              setRecordingSeconds(0);
                            }}
                            className="text-xs text-gray-500 hover:text-rose-600 underline cursor-pointer"
                          >
                            Re-record
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* 31. Date & Time Combined (Scheduling) */}
                {currentQ.type === "datetime" && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-gray-600 mb-1">Date</label>
                      <input
                        type="date"
                        value={answers[currentQ.id]?.date || ""}
                        onChange={(e) => {
                          setRequiredError(null);
                          setAnswers({
                            ...answers,
                            [currentQ.id]: { ...(answers[currentQ.id] || {}), date: e.target.value },
                          });
                        }}
                        className="w-full bg-white border border-gray-300 focus:border-indigo-500 rounded-xl px-4 py-3 text-gray-900 text-xs sm:text-sm outline-none transition"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-gray-600 mb-1">Time</label>
                      <input
                        type="time"
                        value={answers[currentQ.id]?.time || ""}
                        onChange={(e) => {
                          setRequiredError(null);
                          setAnswers({
                            ...answers,
                            [currentQ.id]: { ...(answers[currentQ.id] || {}), time: e.target.value },
                          });
                        }}
                        className="w-full bg-white border border-gray-300 focus:border-indigo-500 rounded-xl px-4 py-3 text-gray-900 text-xs sm:text-sm outline-none transition font-mono"
                      />
                    </div>
                  </div>
                )}

                {/* 32. Date Range (Scheduling) */}
                {currentQ.type === "date_range" && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-gray-600 mb-1 flex items-center gap-1">
                        <CalendarDays className="w-3.5 h-3.5 text-gray-400" />
                        <span>Start Date</span>
                      </label>
                      <input
                        type="date"
                        value={answers[currentQ.id]?.start || ""}
                        onChange={(e) => {
                          setRequiredError(null);
                          setAnswers({
                            ...answers,
                            [currentQ.id]: { ...(answers[currentQ.id] || {}), start: e.target.value },
                          });
                        }}
                        className="w-full bg-white border border-gray-300 focus:border-indigo-500 rounded-xl px-4 py-3 text-gray-900 text-xs sm:text-sm outline-none transition"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-gray-600 mb-1 flex items-center gap-1">
                        <CalendarDays className="w-3.5 h-3.5 text-gray-400" />
                        <span>End Date</span>
                      </label>
                      <input
                        type="date"
                        value={answers[currentQ.id]?.end || ""}
                        onChange={(e) => {
                          setRequiredError(null);
                          setAnswers({
                            ...answers,
                            [currentQ.id]: { ...(answers[currentQ.id] || {}), end: e.target.value },
                          });
                        }}
                        className="w-full bg-white border border-gray-300 focus:border-indigo-500 rounded-xl px-4 py-3 text-gray-900 text-xs sm:text-sm outline-none transition"
                      />
                    </div>
                  </div>
                )}

                {/* 33. Meeting Scheduler Time Slots */}
                {currentQ.type === "scheduler" && (
                  <div className="space-y-3">
                    <p className="text-xs text-gray-500">Select an available appointment time slot:</p>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                      {(currentQ.timeSlots || ["09:00 AM", "10:30 AM", "01:00 PM", "03:30 PM"]).map((slot) => {
                        const isSelected = answers[currentQ.id] === slot;
                        return (
                          <button
                            key={slot}
                            type="button"
                            onClick={() => {
                              setRequiredError(null);
                              setAnswers({ ...answers, [currentQ.id]: slot });
                            }}
                            className={`p-3 rounded-xl border text-xs font-mono font-semibold transition text-center cursor-pointer ${
                              isSelected
                                ? "bg-indigo-600 text-white border-indigo-600 shadow-xs ring-2 ring-indigo-200"
                                : "bg-white hover:bg-gray-50 border-gray-200 text-gray-700 hover:border-gray-300"
                            }`}
                          >
                            {slot}
                          </button>
                        );
                      })}
                    </div>
                    {answers[currentQ.id] && (
                      <div className="text-xs text-emerald-700 bg-emerald-50 border border-emerald-200 p-2.5 rounded-xl font-medium flex items-center gap-1.5">
                        <Check className="w-3.5 h-3.5" />
                        <span>Slot Reserved: {answers[currentQ.id]}</span>
                      </div>
                    )}
                  </div>
                )}

                {/* 34. Image Upload (Media) */}
                {currentQ.type === "image_upload" && (
                  <div className="border-2 border-dashed border-gray-300 hover:border-indigo-400 rounded-2xl p-8 text-center bg-gray-50/50 transition">
                    <ImageIcon className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                    <label className="cursor-pointer">
                      <span className="text-xs font-semibold text-indigo-600 hover:text-indigo-700 underline">
                        Click to select image file
                      </span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            setRequiredError(null);
                            setAnswers({ ...answers, [currentQ.id]: file.name });
                          }
                        }}
                      />
                    </label>
                    <p className="text-[11px] text-gray-400 mt-1">PNG, JPG, WebP up to {currentQ.maxFileSizeMB || 10}MB</p>
                    {answers[currentQ.id] && (
                      <div className="mt-3 inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-lg text-xs font-medium">
                        <Check className="w-3.5 h-3.5" />
                        <span>Uploaded: {answers[currentQ.id]}</span>
                      </div>
                    )}
                  </div>
                )}

                {/* 35. Video Embed (Media) */}
                {currentQ.type === "video_embed" && (
                  <div className="space-y-2">
                    <div className="w-full aspect-video rounded-2xl overflow-hidden bg-black shadow-sm">
                      <iframe
                        src={
                          currentQ.videoUrl?.includes("watch?v=")
                            ? currentQ.videoUrl.replace("watch?v=", "embed/")
                            : currentQ.videoUrl || "https://www.youtube.com/embed/dQw4w9WgXcQ"
                        }
                        title="Embedded video"
                        className="w-full h-full border-0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                      />
                    </div>
                  </div>
                )}

                {/* 36. Image Display Hero (Display & Layout) */}
                {currentQ.type === "image_display" && (
                  <div className="space-y-2">
                    <div className="w-full rounded-2xl overflow-hidden bg-gray-100 shadow-sm border border-gray-200">
                      <img
                        src={currentQ.mediaUrl || "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1000&q=80"}
                        alt={currentQ.title || "Display Media"}
                        className="w-full h-auto object-cover max-h-72"
                      />
                    </div>
                  </div>
                )}

                {/* 37. Rich Text Block (Display & Layout) */}
                {currentQ.type === "rich_text" && (
                  <div className="p-5 rounded-2xl bg-gray-50 border border-gray-200 text-gray-800 text-xs sm:text-sm leading-relaxed whitespace-pre-wrap font-sans">
                    {currentQ.richTextContent || "Provide background instructions, resources, or guidance."}
                  </div>
                )}

                {/* 38. Accordion FAQ (Display & Layout) */}
                {currentQ.type === "accordion" && (
                  <div className="space-y-2">
                    {(currentQ.accordionItems || [
                      { id: "acc-1", title: "Assessment Guidelines", content: "Take your time and verify answers before submitting." },
                      { id: "acc-2", title: "Scoring Criteria", content: "Each question contributes to the cumulative percentage." },
                    ]).map((item) => {
                      const isExpanded = Boolean(expandedAccordions[item.id]);
                      return (
                        <div key={item.id} className="border border-gray-200 rounded-xl overflow-hidden bg-white shadow-xs">
                          <button
                            type="button"
                            onClick={() =>
                              setExpandedAccordions((prev) => ({
                                ...prev,
                                [item.id]: !prev[item.id],
                              }))
                            }
                            className="w-full p-3.5 text-left text-xs font-bold text-gray-900 hover:bg-gray-50 flex items-center justify-between transition cursor-pointer"
                          >
                            <span>{item.title}</span>
                            <ChevronDown className={`w-4 h-4 text-gray-400 transition-transform ${isExpanded ? "rotate-180 text-indigo-600" : ""}`} />
                          </button>
                          {isExpanded && (
                            <div className="p-3.5 pt-0 text-xs text-gray-600 border-t border-gray-100 bg-gray-50/50 leading-relaxed">
                              {item.content}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* 39. Calculation Formula Display (Advanced & Logic) */}
                {currentQ.type === "calculation" && (
                  <div className="p-5 rounded-2xl bg-teal-50/60 border border-teal-200 text-teal-900 space-y-2">
                    <div className="flex items-center gap-2 font-bold text-xs">
                      <Calculator className="w-4 h-4 text-teal-600" />
                      <span>Formula Calculation</span>
                    </div>
                    <div className="font-mono text-xs bg-white/80 p-2.5 rounded-lg border border-teal-200/80 text-teal-800">
                      {currentQ.calculationFormula || "[Computed Value] = Active Formula"}
                    </div>
                  </div>
                )}

                {/* 40. Hidden Variable Field (Advanced & Logic) */}
                {currentQ.type === "hidden" && (
                  <div className="p-3 rounded-xl bg-gray-50 border border-gray-200 text-xs text-gray-500 font-mono flex items-center justify-between">
                    <span>Variable `{currentQ.hiddenParamName || "utm_source"}`:</span>
                    <span className="font-semibold text-gray-800">{answers[currentQ.id] || "auto-captured"}</span>
                  </div>
                )}

                {/* 41. Security CAPTCHA Challenge (Advanced & Logic) */}
                {currentQ.type === "captcha" && (
                  <div className="p-4 bg-white border border-gray-300 rounded-2xl shadow-xs inline-flex items-center gap-4 max-w-sm">
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={Boolean(answers[currentQ.id])}
                        onChange={(e) => {
                          setRequiredError(null);
                          setAnswers({ ...answers, [currentQ.id]: e.target.checked });
                        }}
                        className="w-6 h-6 rounded border-gray-300 text-indigo-600 focus:ring-0 cursor-pointer"
                      />
                      <span className="text-xs font-semibold text-gray-800">I am not a robot</span>
                    </label>
                    <div className="border-l border-gray-200 pl-4 flex flex-col items-center">
                      <ShieldCheck className="w-6 h-6 text-indigo-600" />
                      <span className="text-[9px] text-gray-400 font-mono">reCAPTCHA</span>
                    </div>
                  </div>
                )}
              </div>

              {/* Required field error notification */}
              {requiredError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 font-medium flex items-center gap-2">
                  <XCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>{requiredError}</span>
                </div>
              )}

              {/* Immediate Feedback Card */}
              {immediateFeedback && (
                <motion.div
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`p-4 rounded-xl border ${
                    immediateFeedback.isCorrect
                      ? "bg-emerald-50 border-emerald-200 text-emerald-800"
                      : "bg-rose-50 border-rose-200 text-rose-800"
                  }`}
                >
                  <div className="flex items-start gap-2.5">
                    {immediateFeedback.isCorrect ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                    ) : (
                      <XCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                    )}
                    <div className="text-xs">
                      <div className="font-bold text-sm">
                        {immediateFeedback.isCorrect ? "Correct!" : "Incorrect"}
                      </div>
                      {immediateFeedback.explanation && (
                        <div className="opacity-90 mt-1">
                          {immediateFeedback.explanation}
                        </div>
                      )}
                    </div>
                  </div>
                </motion.div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Bottom Sticky Action Bar */}
      <footer className="w-full border-t border-gray-200 bg-white p-4 sm:px-8 flex items-center justify-between shadow-xs">
        <button
          onClick={goToPrev}
          disabled={history.length <= 1 && currentIndex === 0}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold border transition ${
            history.length <= 1 && currentIndex === 0
              ? "opacity-30 cursor-not-allowed border-gray-200 text-gray-400"
              : "border-gray-300 hover:bg-gray-50 text-gray-700"
          }`}
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back</span>
        </button>

        <div className="flex items-center gap-3">
          {form.settings.enableKeyboardShortcuts && (
            <span className="hidden sm:inline-block text-[11px] text-gray-400 font-mono">
              Press <kbd className="px-1.5 py-0.5 bg-gray-100 border border-gray-200 rounded text-gray-600">Enter ↵</kbd>
            </span>
          )}

          <button
            onClick={goToNext}
            disabled={isSubmitting}
            className="flex items-center gap-2 px-5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold transition shadow-xs disabled:opacity-50 cursor-pointer"
          >
            {isSubmitting ? (
              <span>Submitting...</span>
            ) : calculateNext(currentIndex, answers).type === "ending" ? (
              <>
                <span>Complete & View Score</span>
                <Check className="w-3.5 h-3.5" />
              </>
            ) : (
              <>
                <span>Continue</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </>
            )}
          </button>
        </div>
      </footer>
    </div>
  );
}
