"use client";

import React, { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { FormSchemaType } from "@/lib/schema";
import {
  Sparkles,
  Plus,
  Play,
  Edit3,
  Trash2,
  Copy,
  Layers,
  ArrowRight,
  Code2,
  Check,
  Bot,
  Zap,
} from "lucide-react";
import { nanoid } from "nanoid";

interface DashboardProps {
  initialForms: FormSchemaType[];
}

export default function Dashboard({ initialForms }: DashboardProps) {
  const router = useRouter();
  const [forms, setForms] = useState<FormSchemaType[]>(initialForms);
  const [showAgentModal, setShowAgentModal] = useState(false);
  const [agentTopic, setAgentTopic] = useState("");
  const [agentNumQuestions, setAgentNumQuestions] = useState(5);
  const [isGenerating, setIsGenerating] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCreateBlank = async () => {
    const newId = `quiz-${nanoid(8)}`;
    const newForm: FormSchemaType = {
      id: newId,
      title: "New Assessment",
      description: "Customize questions, scoring rules, and explanations.",
      mode: "quiz",
      theme: {
        id: "fillout-light",
        primaryColor: "#4f46e5",
        accentColor: "#10b981",
        backgroundColor: "#f4f5f7",
        cardColor: "#ffffff",
        textColor: "#111827",
        font: "sans",
        layout: "step",
        borderRadius: "lg",
      },
      settings: {
        showProgressBar: true,
        shuffleQuestions: false,
        timerMinutes: 0,
        passingScorePercentage: 70,
        feedbackMode: "end",
        showAnswerKeyOnFinish: true,
        allowRetake: true,
        enableKeyboardShortcuts: true,
      },
      questions: [
        {
          id: `q-${nanoid(6)}`,
          type: "multiple_choice",
          title: "What is your first question?",
          description: "Add choices below and toggle the checkmark to designate the correct answer.",
          required: true,
          points: 10,
          options: [
            { id: nanoid(4), label: "Correct Option", isCorrect: true, explanation: "Great job!" },
            { id: nanoid(4), label: "Distractor Option", isCorrect: false, explanation: "Try again." },
          ],
          explanation: "Explanation why this is correct.",
        },
      ],
      outcomeTiers: [
        {
          id: "tier-pass",
          minScorePercent: 70,
          maxScorePercent: 100,
          badge: "🏆 Passed",
          title: "Congratulations!",
          message: "You scored above the passing threshold.",
        },
        {
          id: "tier-fail",
          minScorePercent: 0,
          maxScorePercent: 69,
          badge: "🌱 Keep Practicing",
          title: "Review & Retake",
          message: "Review the answers and try again!",
        },
      ],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    try {
      await fetch("/api/forms", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newForm),
      });
      window.location.href = `/editor/${newId}`;
    } catch (err) {
      console.error("Failed to create form:", err);
    }
  };

  const handleAgentGenerate = async () => {
    if (!agentTopic.trim()) return;
    setIsGenerating(true);
    try {
      const res = await fetch("/api/agent/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          topic: agentTopic,
          numQuestions: agentNumQuestions,
        }),
      });
      const data = await res.json();
      if (data.form) {
        window.location.href = `/editor/${data.form.id}`;
      }
    } catch (err) {
      console.error("Agent creation failed:", err);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Are you sure you want to delete this form?")) return;
    try {
      await fetch(`/api/forms/${id}`, { method: "DELETE" });
      setForms(forms.filter((f) => f.id !== id));
    } catch (err) {
      console.error("Delete failed:", err);
    }
  };

  const copyPlayLink = (id: string) => {
    const url = `${window.location.origin}/play/${id}`;
    navigator.clipboard.writeText(url);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="min-h-screen bg-[#f4f5f7] text-gray-900 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      {/* Top Header */}
      <header className="border-b border-gray-200 bg-white px-6 py-3 flex items-center justify-between sticky top-0 z-40 shadow-xs">
        <div className="flex items-center gap-3">
          <Link href="/" className="flex items-center gap-2.5 transition hover:opacity-85">
            <img src="/logo.png" alt="heyquiz" className="h-7 w-auto object-contain" />
          </Link>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setShowAgentModal(true)}
            className="px-3.5 py-1.5 rounded-lg bg-white hover:bg-indigo-50/60 border border-indigo-200 text-indigo-600 text-xs font-semibold flex items-center gap-1.5 transition shadow-xs cursor-pointer"
          >
            <Bot className="w-3.5 h-3.5 text-indigo-500" />
            <span>Create with AI Agent</span>
          </button>

          <button
            onClick={handleCreateBlank}
            className="px-3.5 py-1.5 rounded-lg bg-[#18181b] hover:bg-black text-white text-xs font-semibold flex items-center gap-1.5 shadow-xs transition cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Form</span>
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-6xl w-full mx-auto p-6 sm:p-10 space-y-8">
        {/* Fillout Style Clean Hero Banner */}
        <div className="rounded-2xl bg-white border border-gray-200/90 p-8 sm:p-10 shadow-xs">
          <div className="max-w-2xl space-y-3">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-50 border border-emerald-200 text-[11px] font-semibold text-emerald-700">
              <Zap className="w-3 h-3 text-amber-500 fill-amber-500" />
              <span>Full-Featured Form &amp; Quiz Engine</span>
            </div>

            <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-gray-900">
              Build high-converting forms &amp; quizzes{" "}
              <span className="text-indigo-600">without the clutter.</span>
            </h1>

            <p className="text-gray-500 text-xs sm:text-sm leading-relaxed">
              Every feature of Fillout: question palettes, in-place answer keys, scoring weights, outcome tiers, and an agent-ready API that generates complete quizzes in seconds.
            </p>

            <div className="pt-3 flex flex-wrap gap-3">
              <button
                onClick={() => setShowAgentModal(true)}
                className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs transition flex items-center gap-2 shadow-xs cursor-pointer"
              >
                <Bot className="w-4 h-4 text-indigo-200" />
                <span>Prompt Agent to Build Quiz</span>
              </button>

              <button
                onClick={handleCreateBlank}
                className="px-4 py-2.5 rounded-xl bg-white hover:bg-gray-50 text-gray-700 font-semibold text-xs transition border border-gray-300 shadow-xs flex items-center gap-2 cursor-pointer"
              >
                <span>Blank Canvas Studio</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Form Cards Grid */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-gray-900 flex items-center gap-2">
              <Layers className="w-4 h-4 text-indigo-600" />
              <span>Your Quizzes &amp; Forms ({forms.length})</span>
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {forms.map((item) => {
              const totalPts = item.questions?.reduce((sum, q) => sum + (q.points ?? 0), 0) || 0;
              return (
                <div
                  key={item.id}
                  className="bg-white hover:border-gray-300 border border-gray-200/90 rounded-2xl p-5 flex flex-col justify-between transition-all shadow-xs group"
                >
                  <div className="space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-100">
                        {item.mode}
                      </span>
                      <span className="text-xs text-gray-400 font-mono font-medium">
                        {item.questions?.length || 0} questions · {totalPts} pts
                      </span>
                    </div>

                    <div>
                      <h3 className="text-sm font-bold text-gray-900 group-hover:text-indigo-600 transition line-clamp-1">
                        {item.title}
                      </h3>
                      <p className="text-xs text-gray-500 mt-1 line-clamp-2 leading-relaxed">
                        {item.description || "No description provided."}
                      </p>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-gray-100 mt-4 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Link
                        href={`/editor/${item.id}`}
                        className="px-3 py-1.5 rounded-lg bg-white hover:bg-gray-50 text-gray-700 text-xs font-semibold flex items-center gap-1.5 transition border border-gray-200 shadow-xs"
                      >
                        <Edit3 className="w-3 h-3" />
                        <span>Edit</span>
                      </Link>

                      <Link
                        href={`/play/${item.id}`}
                        target="_blank"
                        className="px-3 py-1.5 rounded-lg bg-indigo-50 hover:bg-indigo-100/70 text-indigo-700 text-xs font-semibold flex items-center gap-1.5 transition border border-indigo-200"
                      >
                        <Play className="w-3 h-3 fill-current" />
                        <span>Play</span>
                      </Link>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => copyPlayLink(item.id)}
                        className="p-1.5 text-gray-400 hover:text-gray-700 rounded hover:bg-gray-100 transition"
                        title="Copy Play Link"
                      >
                        {copiedId === item.id ? (
                          <Check className="w-4 h-4 text-emerald-600 stroke-[3]" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>

                      <button
                        onClick={() => handleDelete(item.id)}
                        className="p-1.5 text-gray-400 hover:text-rose-600 rounded hover:bg-rose-50 transition"
                        title="Delete Quiz"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Agent API Banner */}
        <div className="rounded-2xl bg-white border border-gray-200 p-5 flex flex-col md:flex-row items-center justify-between gap-4 shadow-xs">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Code2 className="w-4 h-4 text-indigo-600" />
              <span className="text-xs font-bold text-gray-900">Agent API Ready</span>
            </div>
            <p className="text-xs text-gray-500">
              External agents can generate quizzes via <code className="text-indigo-600 bg-gray-100 px-1.5 py-0.5 rounded font-mono">POST /api/agent/generate</code>.
            </p>
          </div>
          <div className="text-[11px] font-mono text-gray-600 bg-gray-50 px-3 py-2 rounded-xl border border-gray-200">
            curl -X POST http://localhost:3000/api/agent/generate -d &apos;&#123;&quot;topic&quot;: &quot;Docker Security&quot;&#125;&apos;
          </div>
        </div>
      </main>

      {/* Agent Generator Modal */}
      {showAgentModal && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-gray-200 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
                  <Bot className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-gray-900">Synthesize Quiz with AI Agent</h3>
                  <p className="text-[11px] text-gray-500">Create scored quizzes with answer keys in seconds.</p>
                </div>
              </div>
              <button
                onClick={() => setShowAgentModal(false)}
                className="text-gray-400 hover:text-gray-600 text-sm"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">
                  Quiz Topic or Prompt
                </label>
                <input
                  type="text"
                  autoFocus
                  value={agentTopic}
                  onChange={(e) => setAgentTopic(e.target.value)}
                  placeholder="e.g. React 19 Actions, Python AsyncIO, Kubernetes Networking..."
                  className="w-full bg-gray-50 border border-gray-200 focus:border-indigo-500 focus:bg-white rounded-xl px-3.5 py-2.5 text-xs text-gray-900 outline-none transition"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">
                  Number of Questions
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[3, 5, 8].map((count) => (
                    <button
                      key={count}
                      onClick={() => setAgentNumQuestions(count)}
                      className={`py-2 rounded-lg text-xs font-semibold border transition cursor-pointer ${
                        agentNumQuestions === count
                          ? "bg-indigo-600 border-indigo-600 text-white shadow-xs"
                          : "bg-gray-50 border-gray-200 text-gray-600 hover:bg-gray-100"
                      }`}
                    >
                      {count} Questions
                    </button>
                  ))}
                </div>
              </div>

              <div className="pt-2">
                <button
                  onClick={handleAgentGenerate}
                  disabled={isGenerating || !agentTopic.trim()}
                  className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs transition flex items-center justify-center gap-2 shadow-xs disabled:opacity-50 cursor-pointer"
                >
                  {isGenerating ? (
                    <>
                      <Sparkles className="w-4 h-4 animate-spin text-amber-300" />
                      <span>Synthesizing Questions &amp; Scoring...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 text-amber-300" />
                      <span>Generate &amp; Open Studio</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
