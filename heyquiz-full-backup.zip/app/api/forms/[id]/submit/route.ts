import { NextRequest, NextResponse } from "next/server";
import { getFormById, saveSubmission } from "@/lib/storage";
import { gradeQuizSubmission } from "@/lib/scoring";

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const form = getFormById(id);
  if (!form) {
    return NextResponse.json({ error: "Form not found" }, { status: 404 });
  }

  try {
    const body = await req.json();
    const answers = body.answers || {};
    const forcedTierId = body.forcedTierId;
    const result = gradeQuizSubmission(form, answers);

    if (forcedTierId && form.outcomeTiers) {
      const explicitTier = form.outcomeTiers.find((t) => t.id === forcedTierId);
      if (explicitTier) {
        result.matchedTier = explicitTier;
      }
    }

    result.answers = answers;

    // Detect respondent name or email if captured in answers
    for (const [qId, val] of Object.entries(answers)) {
      const q = form.questions.find((quest) => quest.id === qId);
      if (q && (q.type === "email" || q.title.toLowerCase().includes("name") || q.title.toLowerCase().includes("email"))) {
        result.respondentName = String(val);
        break;
      }
    }

    const saved = saveSubmission(result);
    return NextResponse.json(saved);
  } catch (err: any) {
    console.error("Submission error:", err);
    return NextResponse.json(
      { error: "Grading failed", details: err?.message },
      { status: 500 }
    );
  }
}
