import { NextRequest, NextResponse } from "next/server";
import { getFormById, getSubmissionsByFormId, deleteSubmission } from "@/lib/storage";

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const form = getFormById(id);
  if (!form) {
    return NextResponse.json({ error: "Form not found" }, { status: 404 });
  }

  const submissions = getSubmissionsByFormId(id);

  // Compute aggregate stats
  const total = submissions.length;
  const passedCount = submissions.filter((s) => s.passed).length;
  const failedCount = total - passedCount;
  const passRate = total > 0 ? Math.round((passedCount / total) * 100) : 0;
  const averageScore =
    total > 0
      ? Math.round(submissions.reduce((sum, s) => sum + s.percentageScore, 0) / total)
      : 0;

  // Breakdown by tier
  const tierDistribution: Record<string, number> = {};
  for (const s of submissions) {
    const tierName = s.matchedTier?.title || (s.passed ? "Passed" : "Completed");
    tierDistribution[tierName] = (tierDistribution[tierName] || 0) + 1;
  }

  return NextResponse.json({
    formId: id,
    submissions,
    stats: {
      total,
      passedCount,
      failedCount,
      passRate,
      averageScore,
      tierDistribution,
    },
  });
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const { searchParams } = new URL(req.url);
  const submissionId = searchParams.get("submissionId");

  if (!submissionId) {
    return NextResponse.json({ error: "Missing submissionId" }, { status: 400 });
  }

  const success = deleteSubmission(submissionId);
  return NextResponse.json({ success });
}
