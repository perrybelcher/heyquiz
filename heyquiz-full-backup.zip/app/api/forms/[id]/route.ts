import { NextRequest, NextResponse } from "next/server";
import { getFormById, saveForm, deleteForm } from "@/lib/storage";
import { FormSchema } from "@/lib/schema";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const form = getFormById(id);
  if (!form) {
    return NextResponse.json({ error: "Form not found" }, { status: 404 });
  }
  return NextResponse.json(form);
}

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  try {
    const body = await req.json();
    const parsed = FormSchema.parse({ ...body, id });
    const saved = saveForm(parsed);
    return NextResponse.json(saved);
  } catch (err: any) {
    return NextResponse.json(
      { error: "Invalid form schema", details: err?.errors || err?.message },
      { status: 400 }
    );
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const deleted = deleteForm(id);
  if (!deleted) {
    return NextResponse.json({ error: "Form not found" }, { status: 404 });
  }
  return NextResponse.json({ success: true, id });
}
