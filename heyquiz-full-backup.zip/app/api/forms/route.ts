import { NextRequest, NextResponse } from "next/server";
import { getAllForms, saveForm } from "@/lib/storage";
import { FormSchema } from "@/lib/schema";

export async function GET() {
  const forms = getAllForms();
  return NextResponse.json(forms);
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = FormSchema.parse(body);
    const saved = saveForm(parsed);
    return NextResponse.json(saved, { status: 201 });
  } catch (err: any) {
    console.error("Failed to save form:", err);
    return NextResponse.json(
      { error: "Invalid form schema", details: err?.errors || err?.message },
      { status: 400 }
    );
  }
}
