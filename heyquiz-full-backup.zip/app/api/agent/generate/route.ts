import { NextRequest, NextResponse } from "next/server";
import { generateQuizWithAgent } from "@/lib/agent-generator";
import { saveForm } from "@/lib/storage";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const generatedForm = generateQuizWithAgent({
      prompt: body.prompt,
      topic: body.topic,
      numQuestions: body.numQuestions,
      difficulty: body.difficulty,
      mode: body.mode,
      timerMinutes: body.timerMinutes,
    });

    // Save to storage immediately so it's live
    const saved = saveForm(generatedForm);

    return NextResponse.json({
      success: true,
      form: saved,
      playUrl: `/play/${saved.id}`,
      editorUrl: `/editor/${saved.id}`,
      message: `Successfully synthesized quiz "${saved.title}" with ${saved.questions.length} questions.`,
    });
  } catch (err: any) {
    console.error("Agent generation error:", err);
    return NextResponse.json(
      { error: "Failed to generate quiz", details: err?.message },
      { status: 500 }
    );
  }
}
