import { notFound } from "next/navigation";
import { getFormById } from "@/lib/storage";
import EditorStudio from "@/components/EditorStudio";

export default async function EditorPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const form = getFormById(id);

  if (!form) {
    notFound();
  }

  return <EditorStudio initialForm={form} />;
}
