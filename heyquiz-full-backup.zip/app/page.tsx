import { getAllForms } from "@/lib/storage";
import Dashboard from "@/components/Dashboard";

export default async function HomePage() {
  const forms = getAllForms();
  return <Dashboard initialForms={forms} />;
}
