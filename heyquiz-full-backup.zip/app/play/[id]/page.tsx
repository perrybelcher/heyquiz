import { notFound } from "next/navigation";
import { getFormById } from "@/lib/storage";
import QuizPlayer from "@/components/QuizPlayer";

export default async function PlayPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const form = getFormById(id);

  if (!form) {
    notFound();
  }

  return <QuizPlayer form={form} />;
}
